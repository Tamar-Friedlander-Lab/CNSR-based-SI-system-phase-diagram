#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import matplotlib as mpl # type: ignore
import seaborn as sns # type: ignore
from matplotlib.ticker import FormatStrFormatter # type: ignore
import matplotlib.colors as mcolors  # type: ignore
import matplotlib as mpl # type: ignore
import matplotlib # type: ignore
matplotlib.use('TKAgg') # alternate when qt.qpa.plugin: Could not find the Qt platform plugin "wayland" in ""
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)




weight = [0.5, 0.265, 0.113, 0.122]
def si_counts_fig(input_Var):


    tot_population = 2000
    each_alpha = 0.60
    delta_s_e = [[], [], [], [], [], [], [], [], []]
    th_criteria_l = 0.11
    th_criteria_h = 1 - th_criteria_l
    main_path = '../../phase_transition_backword_a60'




    #fig = plt.figure(figsize=(8,3.0))
    # f, (ax) = plt.subplots(1, 1, gridspec_kw={'width_ratios': [1.0]}, figsize=(3.75,3.25))
    f, (ax, ax1) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1.0, 1]}, figsize=(6.5,3.5))
    # plt.subplots_adjust(top=0.938, bottom=0.125, left=0.123, right=0.883, hspace=0.5, wspace=0.0)
    plt.subplots_adjust(top=0.938, bottom=0.118, left=0.071, right=0.993, hspace=0.65, wspace=0.0)
    fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
    AminoAcid = ['H', 'P', '+', '-']
    color = ['b', 'b', 'b']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
    tickswidth, tickssize = 0.35, 1.0


    energy_variable = [-10.25, -9, -8, -7, -6, -5, -4, -3, -1.75]
    delta_variable = np.arange(0.75, 1.01, 0.01)

    #ax = plt.subplot(1,2,1)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)
    for axis in ['top','bottom','left','right']:    ax.spines[axis].set_linewidth(0.35)
    ax.tick_params(axis='both', which='both', width=tickswidth)

    print (mcolors.TABLEAU_COLORS)
    # ax.plot(line_sc[:-2], energy_variable[:-2], '-', color='k', linewidth=0.25)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
    # ax.plot(line_si[:-2], energy_variable[:-2], '-', color='k', linewidth=0.25)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)


    alpha1 = 0.35; subs_value = -0.000

    #energy_variable = [-10.25, -9, -8, -7, -6, -5, -4, -3, -2]


    temp_energy_variable = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2])
    circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87]
    circles_sc_si_to_plot = np.array([14, 14, 14, 16, 18, 20, 22, 25])
    # ax.plot([0.865]*len(circles_to_plot1), temp_energy_variable, \
    #             'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
    # ax.plot(delta_variable[circles_sc_si_to_plot]-0.005, \
    #             np.arange(-2.0, -10.25, -0.25)[np.array([0, 4, 8, 10, 12, 14, 15, 16])], \
    #                 'o', ms=3.5, color='k')

    ax.fill_between([0.75, 0.865, 0.865, 1.0], [-10.25, -10.25, -4.5, -4.5], -1.75, color=mcolors.TABLEAU_COLORS['tab:red'], alpha=alpha1, edgecolor="None")
    ax.fill_between([0.865]+list(delta_variable[circles_sc_si_to_plot]-0.005) + [1.0], \
                        [-4.5]+list(np.arange(-2.0, -10.25, -0.25)[np.array([10, 10, 10, 10, 12, 14, 15, 16])]) + [-6], \
                            -10.15, color=mcolors.TABLEAU_COLORS['tab:green'], \
                                alpha=alpha1, edgecolor="None")
    ax.fill_between(list(delta_variable[circles_sc_si_to_plot]-0.005) + [1.0], \
                        list(np.arange(-2.0, -10.25, -0.25)[np.array([10, 10, 10, 10, 12, 14, 15, 16])]) + [-6], \
                            -4.5, color=mcolors.TABLEAU_COLORS['tab:blue'], \
                                alpha=alpha1, edgecolor="None")
    
    # ax.fill_between(fill_3_x, fill_3_y2, -10.15, color=mcolors.TABLEAU_COLORS['tab:blue'], alpha=alpha1, edgecolor="None")
    
    ax.fill_between([0.865, 1.0], [-4.5, -4.5], -1.85, facecolor="none", edgecolor="k", hatch='////', linewidth=0.00)
    mpl.rcParams['hatch.linewidth'] = 0.25


    #ax.set_title(r'(IPR)', fontsize=fontsizeX-2, x=0.765, y=-0.285)
    #ax.set_ylabel('Fraction', fontsize=fontsizeY)

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0, top=True)
    ax.set_xticks(np.arange(0.75,1.01,0.05/5), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks, top=True)
    ax.set_xticks(np.arange(0.75,1.01,0.05), minor = False)

    #ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
    #ax.set_yticks(np.arange(-9.0,-1.0,2), [-9, -7, -5, -3], minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(-10.0,-1.0,1), minor = False)

    ax.text(0.76, -5.75, 'self-compatible', fontsize=fontsizeX-1, color='k')
    ax.text(0.915, -7.5, 'mixed', fontsize=fontsizeX-1, color='k')
    ax.text(0.932, -5.185, 'self-\nincompatible', fontsize=fontsizeX-1, color='k', rotation=0)
    ax.text(0.885, -3.5, 'no emergence of \nself-incompatibility', fontsize=fontsizeX-1, color='k', \
            rotation=0, bbox=dict(facecolor='w', alpha=1.0, edgecolor='k', boxstyle='round, pad=0.2'))

    ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeX)
    ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeY, labelpad=-2.5)
    # ax.set_title(r'Self-pollination rate, $\alpha$=0.60', loc='center', fontsize=fontsizeX-2)
    ax.set_title(Title[0], loc='left', fontweight='bold')

    ax.set_ylim([-10.0, -2.0])
    ax.set_xlim([0.75, 1.0])


    ax2 = ax.twinx()
    #ax1.spines.right.set_visible(False)
    #ax1.spines.top.set_visible(False)
    for axis in ['top','bottom','left','right']:    ax2.spines[axis].set_linewidth(0.35)
    ax2.tick_params(axis='both', which='both', width=tickswidth)

    #ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
    #ax1.set_yticks([1, 3, 5, 7], [4, 7, 10, ''], minor = True)
    ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax2.set_yticks([0, 1, 2, 3, 4, 5, 6, 7, 8], [2, 3, 4, 5, 7, 9, 11, 12, 12], minor = False)

    ax2.set_ylim([0, 8.0])
    ax2.set_ylabel(r'Class number, $K(E_{\mathrm{th}})$', fontsize=fontsizeY)


    for axis in ['top','bottom','left','right']:
        ax1.spines[axis].set_visible(False)
    ax1.set_xticks([])
    ax1.set_yticks([])











    #
    #
    #
    #
    eth2_forward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                        1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]
    eth2_f_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.865, \
                        0.865, 0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]

    eth2_backward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    eth2_b_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 
                        0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]
    




    eth6_forward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, \
                            1.0, 1.0]
    eth6_f_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.865, \
                        0.865, 0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 0.995, \
                            0.995, 1]

    eth6_backward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, \
                            1.0, 1.0]
    eth6_b_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.865, \
                        0.865, 0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 0.995, \
                            0.995, 1]




    eth10_forward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
    eth10_f_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.865, \
                        0.865, 0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]

    eth10_backward = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, \
                        0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5, 0.5]
    eth10_b_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , 0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.865, \
                        0.865, 0.87, 0.88, 0.89, 0.9 , 0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]

    each_alpha = 0.60


    ax = plt.subplot(3,3,(0)*3 + 3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    ax.fill_between(eth2_f_delta, 0, eth2_forward, color=mcolors.TABLEAU_COLORS['tab:red'], alpha=0.25, linewidth=0.0)
    plt.plot(eth2_f_delta, eth2_forward, '-o', color=mcolors.TABLEAU_COLORS['tab:blue'], \
                linewidth=0.75, ms=3.5, label='initialization \nwith SI')
    plt.plot(eth2_b_delta, eth2_backward, '-o', color=mcolors.TABLEAU_COLORS['tab:red'], \
                linewidth=0.75, ms=1.25, label='initialization \nwith SC')

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0)
    ax.set_xticks(np.arange(0.75,1.01,0.01), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
    ax.set_xticks(np.arange(0.75,1.01,0.05), minor = False)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1, pad=4)
    ax.set_yticks(np.arange(-0.0, 1.02, 0.5), ['SC', 'Mixed', 'SI'], minor = False)

    plt.text(0.9, 0.5, r'$E_{\mathrm{th}}$=-2',fontsize=fontsizeX-3)
    # ax.set_xlabel(r'$\delta$', fontsize=fontsizeY)
    # ax.set_title(r'$E_{\mathrm{th}}$=-2', loc='right', fontsize=fontsizeX-3)
    ax.set_title(Title[1], loc='left', fontweight='bold')
    ax.legend(fontsize=fontticks-2, frameon=False, loc=2, ncol=1)

    ax.set_ylim([-0.08, 1.06])
    ax.set_xlim([+0.74, 1.01])











    ax = plt.subplot(3,3,(1)*3 + 3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    #ax.fill_between(eth6_b_delta, 0, eth6_backward, color=mcolors.TABLEAU_COLORS['tab:blue'], alpha=0.25, linewidth=0.0)
    plt.plot(eth6_f_delta, eth6_forward, '-o', color=mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75, ms=3.5, label='initialize with SI')
    plt.plot(eth6_b_delta, eth6_backward, '-o', color=mcolors.TABLEAU_COLORS['tab:red'], linewidth=0.75, ms=1.25, label='initialize with SC')

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0)
    ax.set_xticks(np.arange(0.75,1.01,0.01), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
    ax.set_xticks(np.arange(0.75,1.01,0.05), minor = False)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1, pad=4)
    ax.set_yticks(np.arange(-0.0, 1.02, 0.5), ['SC', 'Mixed', 'SI'], minor = False)

    plt.text(0.9, 0.75, r'$E_{\mathrm{th}}$=-6',fontsize=fontsizeX-3)
    # ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY-2, labelpad=7)
    # ax.set_title(r'$E_{\mathrm{th}}$=-6', loc='right', fontsize=fontsizeX-3)
    # ax.set_title(Title[0], loc='left', fontweight='bold')
    # ax.legend(fontsize=fontticks-1, frameon=False, loc=2, ncol=1)

    ax.set_ylim([-0.08, 1.06])
    ax.set_xlim([+0.74, 1.01])














    ax = plt.subplot(3,3,(2)*3 + 3)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)

    # ax.fill_between([0.75, 0.78], [0.5, 0.5], [1.0, 1.0], color='k', alpha=0.25, linewidth=0.0, edgecolor=(0,0,0,0.25))
    #ax.fill_between(eth10_b_delta, 0, eth10_backward, color=mcolors.TABLEAU_COLORS['tab:blue'], alpha=0.25, linewidth=0.0)

    plt.plot(eth10_f_delta, eth10_forward, '-o', color=mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75, ms=3.5, label='initialize with SI')
    plt.plot(eth10_b_delta, eth10_backward, '-o', color=mcolors.TABLEAU_COLORS['tab:red'], linewidth=0.75, ms=1.25, label='initialize with SC')

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0)
    ax.set_xticks(np.arange(0.75,1.01,0.01), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
    ax.set_xticks(np.arange(0.75,1.01,0.05), minor = False)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1, pad=4)
    ax.set_yticks(np.arange(-0.0, 1.02, 0.5), ['SC', 'Mixed', 'SI'], minor = False)

    plt.text(0.9, 0.75, r'$E_{\mathrm{th}}$=-10',fontsize=fontsizeX-3)
    ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY-2, labelpad=7)
    # ax.set_title(r'$E_{\mathrm{th}}$=-10', loc='right', fontsize=fontsizeX-3)
    # ax.set_title(Title[0], loc='left', fontweight='bold')
    # ax.legend(fontsize=fontticks-1, frameon=False, loc=2, ncol=1)

    ax.set_ylim([-0.08, 1.06])
    ax.set_xlim([+0.74, 1.01])





    #plt.tight_layout()
    plt.savefig('./figures/fig_6.pdf', transparent=True, dpi=1000)
    #plt.show()
    plt.close()

    return 'done'


print (si_counts_fig(0))


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
