#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
#from numba import jit # type: ignore
import pickle
import glob
#from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import seaborn as sns # type: ignore
import matplotlib as mpl # type: ignore
import statsmodels.api as sm # type: ignore
import matplotlib.gridspec as gridspec
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

def si_line(class_no, alpha, A2): return 0.5 + (1 - A2)/(2*alpha*(class_no - 1 + A2))

energy_variable = [-10, \
                -9.75, -9.5, -9.25, -9, \
                    -8.75, -8.5, -8.25, -8, \
                        -7.75, -7.5, -7.25, -7, \
                            -6.75, -6.5, -6.25, -6, \
                                -5.75, -5.5, -5.25, -5, \
                                    -4.75, -4.5, -4.25, -4, \
                                        -3.75, -3.5, -3.25, -3, \
                                            -2.75, -2.5, -2.25, -2]

delta_variable = [np.round(t_delta, decimals=2) for t_delta in np.arange(0.75, 1.01, 0.01)]
energy_variable = np.array(energy_variable[:])
delta_variable = np.array(delta_variable[:])

def mixedsi(k, a): return (2*(2-a))/(a*(k-2))

#class_data = np.genfromtxt('./class_no_copied_from_phase_trans_finner.dat')
class_data = np.genfromtxt('./data/class_number_main.dat')
std_class_data = np.genfromtxt('./data/cv_class_number_main.dat')
# print(class_data, list(class_data[:,19]), np.shape(class_data))


# for i in range(5):
#     class_data[i, 19] = 0.0

# for i in range(5):
#     print(class_data[i, 19])



fig = plt.figure(figsize=(7.5, 9.0))
#fig, axes = plt.subplots(3, 1, figsize=(4.25, 10.0), gridspec_kw={'width_ratios': [1.0], 'height_ratios': [3.5, 3.5, 2.5]})
gs = gridspec.GridSpec(3, 22,  height_ratios=[5.5, 5.5, 4.5], width_ratios= [1 for _ in range(22)])
plt.subplots_adjust(top=0.975, bottom=0.045, left=0.071, right=0.9935, hspace=0.400, wspace=1.000)
fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 7
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0


# [ 9. 10. 11. 12. 13. 14.] [  37  572 1525 1602  553   50]
# [ 1.  2.  3.  4.  5.  6.  7.  8.  9. 10. 11.] [   4   50  165  345  525  761  934 1009  777  287   34]
# [0. 1. 2. 3. 4. 5. 6.] [  2 171 762 762 300  67  21]

cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.color_palette("Spectral", n_colors=None, as_cmap=True)
#ax1 = plt.subplot(3,1,1)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[1,:10])
# class_data_to_plot = np.concatenate((np.zeros((33, 25)), class_data), axis=1)
# print(class_data)
class_data = class_data[::-1]
print('Class number avg min, max:', np.min(class_data), np.max(class_data))
class_data = np.concatenate((np.zeros((33, 12)), class_data[:, 12:]), axis=1)
ax = sns.heatmap(class_data, cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, cbar_kws={"ticks": [i for i in range(12)],\
                    'label':r'mean effective class number, $\langle K \rangle$',\
                    'shrink':1.00},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)



temp_energy_variable = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2])
temp_temp_energy_variable = np.array([-10, -9.75, -9, -8, -7, -6, -5, -4, -3, -2])
line_sc = [0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75]
line_si = [0.75, 0.72, 0.66, 0.63, 0.6, 0.6, 0.6, 0.6, 0.6]

# ax.plot([tx/0.03 + 0.5 for tx in line_sc], [0.5+(ty+10)/0.25 for ty in temp_temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
# ax.plot([tx/0.03 + 1.5 for tx in line_si], [0.5+(ty+10)/0.25 for ty in temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)


circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87] # taking maximum average number of classes over different deltas
# classes_number  = [3.80, 4.3, 5.20, 7.1, 8.96, 9.81, 10.90, 1.0, 1.0]# taking maximum average number of classes over different deltas 
# for each_class in classes_number:
#     if each_class != 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.1))
#     if each_class == 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.9))

circles_sc_si_to_plot = [13, 13, 13, 18, 25]
# classes_number = [1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
# for each_class in classes_number:
#     circles_sc_si_to_plot.append(si_line(each_class, 0.6, 0.9))

# print('\n')
# print(circles_sc_si_to_plot)
# print(energy_variable)
#sns.lineplot(x=circles_to_plot1, y=energy_variable[:-2])#, color=mcolors.TABLEAU_COLORS['tab:gray'])
#sns.lineplot(x=circles_sc_si_to_plot, y=np.array(list(range(len(energy_variable))))+1.0, palette='r')#, color=mcolors.TABLEAU_COLORS['tab:red'])

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], '--', linewidth=0.75, color='k')
ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')

std_calculation = np.concatenate((np.zeros((33, 12)), std_class_data[::-1][:, 12:]), axis=1)*class_data
print_std_calculation = [std_calculation[int(ind_y), int(ind_x)]/class_data[int(ind_y), int(ind_x)] \
                            for ind_x, ind_y in \
                                zip(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5])]
print_std_calculation = np.array(print_std_calculation)/((2.5/3)*max(print_std_calculation))
print_std_calculation = list(print_std_calculation)
upper_error_x = np.array(circles_sc_si_to_plot) + np.array(print_std_calculation)
upper_error_y = np.array([0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5]) - np.array(print_std_calculation)
ax.plot(upper_error_x, upper_error_y, '-', linewidth=1.25, ms=1.5, color='k', alpha=0.5)

lower_error_x = np.array([circles_sc_si_to_plot[0]]+circles_sc_si_to_plot+[circles_sc_si_to_plot[-1]+3.5]) - np.array([print_std_calculation[0]]+print_std_calculation+[print_std_calculation[-1]])
lower_error_y = np.array([-0.5]+[0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5]+[18.25]) + np.array([0.0]+print_std_calculation+[print_std_calculation[-1]])
ax.plot(lower_error_x, lower_error_y, '-', linewidth=1.25, ms=1.5, color='k', alpha=0.5)

# print(print_std_calculation)




class_no = [6.67, 6.85, 6.95]#np.arange(6.67,7.35,0.05)
dict_delta = {delta_t:iii for iii, delta_t in enumerate(delta_variable)}
ax.plot([dict_delta[np.round(mixedsi(k, 0.6), decimals=2)] for k in class_no], [14.5, 15.5, 16.5][::-1], 'ro', ms=2.5, label='SC-Mixed phase boundary (a=0.6)')
# print([np.round(mixedsi(k, 0.6), decimals=2) for k in class_no])
ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 16.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 6, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 22, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('c', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)


#plt.tight_layout()
#plt.savefig('./figures/fig_class_no_heat_map.pdf', dpi=600)
#plt.show()
#plt.close()











# fig = plt.figure(figsize=(4.75,3.75))
# plt.subplots_adjust(top=0.993, bottom=0.153, left=0.119, right=1.036, hspace=0.5, wspace=0.0)
# fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0

#cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.diverging_palette(250, 0, l=45, center="light", as_cmap=True)
cmap = sns.color_palette("Spectral", n_colors=None, as_cmap=True)
#ax1 = plt.subplot(3,1,2)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[1,12:])
# data_to_plot = np.divide(std_class_data, class_data, out=np.zeros_like(std_class_data), where=class_data!=0)
data_to_plot = std_class_data[::-1]
data_to_plot = np.concatenate((np.zeros((33, 12)), data_to_plot[:, 12:]), axis=1)
# xx = np.array(np.unique(data_to_plot, return_counts=True, axis=None))
# xx = xx.T
# for i in range(33):
#     for j in range(13):
#         data_to_plot[i, j] = 0
xx = np.array(np.unique(data_to_plot, return_counts=True, axis=None))
xx = xx.T
# print(xx, sum(xx[:,1]), sum(xx[54:,1]), xx[:,1]/np.sum(xx[:,1]))
# print(xx[53,0], sum(xx[:,1]), sum(xx[:54,1])/sum(xx[:,1]), 'avg =', sum(xx[:,0]*xx[:,1])/sum(xx[:,1]) )
# print('Class number CV min, max:', np.min(data_to_plot), np.max(data_to_plot))
print('Class number STD min, max:', np.min(np.multiply(data_to_plot, class_data)), np.max(np.multiply(data_to_plot, class_data)))
# ax = sns.heatmap(np.multiply(data_to_plot, class_data), cmap=cmap, rasterized=True, \
ax = sns.heatmap(np.multiply(data_to_plot, class_data), cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, \
                    vmax=5.32, vmin=0.0, \
                    cbar_kws={"ticks": [i/1 for i in range(0,6,1)],\
                    'label':r'effective class number STD',\
                    'shrink':1.0},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], '--', linewidth=0.75, color='k')
ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')
class_no = [6.67, 6.85, 6.95]#np.arange(6.67,7.35,0.05)
dict_delta = {delta_t:iii for iii, delta_t in enumerate(delta_variable)}
ax.plot([dict_delta[np.round(mixedsi(k, 0.6), decimals=2)] for k in class_no], [14.5, 15.5, 16.5][::-1], 'ro', ms=2.5, label='SC-Mixed phase boundary (a=0.6)')
ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)



std_calculation = np.concatenate((np.zeros((33, 12)), std_class_data[::-1][:, 12:]), axis=1)*class_data
# print_std_calculation = [std_calculation[int(ind_y), int(ind_x)]/class_data[int(ind_y), int(ind_x)] \
#                             for ind_x, ind_y in \
#                                 zip(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5])]
# print_std_calculation = np.array(print_std_calculation)/((2.5/3)*max(print_std_calculation))
# print_std_calculation = list(print_std_calculation)
upper_error_x = np.array(circles_sc_si_to_plot) + np.array(print_std_calculation)
upper_error_y = np.array([0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5]) - np.array(print_std_calculation)
ax.plot(upper_error_x, upper_error_y, '-', linewidth=1.25, ms=1.5, color='k', alpha=0.5)

lower_error_x = np.array([circles_sc_si_to_plot[0]]+circles_sc_si_to_plot+[circles_sc_si_to_plot[-1]+3.5]) - np.array([print_std_calculation[0]]+print_std_calculation+[print_std_calculation[-1]])
lower_error_y = np.array([-0.5]+[0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5]+[18.25]) + np.array([0.0]+print_std_calculation+[print_std_calculation[-1]])
ax.plot(lower_error_x, lower_error_y, '-', linewidth=1.25, ms=1.5, color='k', alpha=0.5)


y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 16.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 6, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 22, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('d', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)























#class_data = np.genfromtxt('./class_no_copied_from_phase_trans_finner.dat')
class_data = np.genfromtxt('./data/si_avg_data_main.dat')
std_class_data = np.genfromtxt('./data/si_std_data_main.dat')
# print(class_data, list(class_data[:,19]), np.shape(class_data))


cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.color_palette("Spectral", n_colors=None, as_cmap=True)
#ax1 = plt.subplot(3,1,1)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[0,:10])
# class_data_to_plot = np.concatenate((np.zeros((33, 25)), class_data), axis=1)
# print(class_data)
class_data = class_data[::-1]
# class_data = np.concatenate((np.zeros((33, 12)), class_data[:, 12:]), axis=1)
# print('SI fraction avg min, max:', np.min(class_data), np.max(class_data))
ax = sns.heatmap(class_data, cmap=cmap, rasterized=True, \
                    vmax=1.0, vmin=0.0, \
                    cbar=True, ax=ax_to_plot, cbar_kws={"ticks": [np.round(i/5, 2) for i in range(6)],\
                    'label':r'mean SI fraction',\
                    'shrink':1.00},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)



temp_energy_variable = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2])
temp_temp_energy_variable = np.array([-10, -9.75, -9, -8, -7, -6, -5, -4, -3, -2])
line_sc = [0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75]
line_si = [0.75, 0.72, 0.66, 0.63, 0.6, 0.6, 0.6, 0.6, 0.6]

# ax.plot([tx/0.03 + 0.5 for tx in line_sc], [0.5+(ty+10)/0.25 for ty in temp_temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
# ax.plot([tx/0.03 + 1.5 for tx in line_si], [0.5+(ty+10)/0.25 for ty in temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)


circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87] # taking maximum average number of classes over different deltas
# classes_number  = [3.80, 4.3, 5.20, 7.1, 8.96, 9.81, 10.90, 1.0, 1.0]# taking maximum average number of classes over different deltas 
# for each_class in classes_number:
#     if each_class != 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.1))
#     if each_class == 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.9))

circles_sc_si_to_plot = [13, 13, 13, 18, 25]
# classes_number = [1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
# for each_class in classes_number:
#     circles_sc_si_to_plot.append(si_line(each_class, 0.6, 0.9))

# print('\n')
# print(circles_sc_si_to_plot)
# print(energy_variable)
#sns.lineplot(x=circles_to_plot1, y=energy_variable[:-2])#, color=mcolors.TABLEAU_COLORS['tab:gray'])
#sns.lineplot(x=circles_sc_si_to_plot, y=np.array(list(range(len(energy_variable))))+1.0, palette='r')#, color=mcolors.TABLEAU_COLORS['tab:red'])

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], '--', linewidth=0.75, color='k')
ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')
class_no = [6.67, 6.85, 6.95]#np.arange(6.67,7.35,0.05)
dict_delta = {delta_t:iii for iii, delta_t in enumerate(delta_variable)}
ax.plot([dict_delta[np.round(mixedsi(k, 0.6), decimals=2)] for k in class_no], [14.5, 15.5, 16.5][::-1], 'ro', ms=2.5, label='SC-Mixed phase boundary (a=0.6)')
ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 16.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 6, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 22, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('a', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)


#plt.tight_layout()
#plt.savefig('./figures/fig_class_no_heat_map.pdf', dpi=600)
#plt.show()
#plt.close()











# fig = plt.figure(figsize=(4.75,3.75))
# plt.subplots_adjust(top=0.993, bottom=0.153, left=0.119, right=1.036, hspace=0.5, wspace=0.0)
# fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0

#cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.diverging_palette(250, 0, l=45, center="light", as_cmap=True)
cmap = sns.color_palette("Spectral", n_colors=None, as_cmap=True)
#ax1 = plt.subplot(3,1,2)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[0,12:])
# data_to_plot = np.divide(std_class_data, class_data, out=np.zeros_like(std_class_data), where=class_data!=0)
data_to_plot = std_class_data[::-1]
# data_to_plot = np.concatenate((np.zeros((33, 12)), data_to_plot[:, 12:]), axis=1)
# print('SI fraction STD min, max:', np.min(data_to_plot), np.max(data_to_plot))
ax = sns.heatmap(data_to_plot, cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, \
                    vmax=0.46, vmin=0.0, \
                    cbar_kws={"ticks": [i/10 for i in range(6)],\
                    'label':r'SI fraction STD',\
                    'shrink':1.0},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], '--', linewidth=0.75, color='k')
ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')
class_no = [6.67, 6.85, 6.95]#np.arange(6.67,7.35,0.05)
dict_delta = {delta_t:iii for iii, delta_t in enumerate(delta_variable)}
ax.plot([dict_delta[np.round(mixedsi(k, 0.6), decimals=2)] for k in class_no], [14.5, 15.5, 16.5][::-1], 'ro', ms=2.5, label='SC-Mixed phase boundary (a=0.6)')
ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 16.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 6, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(16.5, 22, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('b', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)























lw=0.15; ms1=0.15; ms2=3.5

def smooth_time_series(input_Var, wind_size):

    output_Var = np.zeros(len(input_Var))
    tracker = 0

    for ind in range(len(input_Var)):
        if input_Var[ind] != np.nan:

            if ind - wind_size >= 0:
                s_ind = ind-wind_size
                e_ind = s_ind + 2*wind_size + 1
                data_to_mean = input_Var[s_ind:e_ind]
                data_to_mean = data_to_mean[~np.isnan(data_to_mean)]
                output_Var[ind] = np.mean(data_to_mean)

            else:
                s_ind = ind - tracker
                e_ind = wind_size + 1 + tracker
                data_to_mean = input_Var[s_ind:e_ind]
                data_to_mean = data_to_mean[~np.isnan(data_to_mean)]
                output_Var[ind] = np.mean(data_to_mean)
                tracker += 1

        else:
            output_Var[ind] = np.nan


    return output_Var

# def acf(time_series, lag_size):
#     lag_size = lag_size + 1
#     total_data_points = len(time_series)
#     time_series = np.array(time_series)

#     data_mean = np.mean(time_series)
#     data_square = np.sum(time_series*time_series)
#     data_var = np.std(time_series)**2

#     acf_data = [0 for _ in range(lag_size)]
#     for lag_ind in range(lag_size):

#         if lag_ind == 0:
#             ser_t   = time_series[:]
#             ser_t_l = time_series[:]

#         else:
#             ser_t   = time_series[lag_ind:]
#             ser_t_l = time_series[:-lag_ind]

#         data_mean = 0.0
#         ser_t   = ser_t - data_mean
#         ser_t_l = ser_t_l - data_mean

#         sum_var = sum(ser_t * ser_t_l) / (total_data_points - lag_ind)
#         #acf_data[lag_ind] = sum_var / data_var
#         acf_data[lag_ind] = sum_var / (data_square/total_data_points)

#     return np.array(acf_data)


def acf(time_series, lag_size):
    lag_size = lag_size + 1
    total_data_points = len(time_series)
    time_series = np.array(time_series)

    data_mean = np.mean(time_series)
    data_square = np.sum(time_series*time_series)
    data_var = np.std(time_series)**2

    acf_data = [0 for _ in range(lag_size)]
    for lag_ind in range(lag_size):

        if lag_ind == 0:
            ser_t   = time_series[:]
            ser_t_l = time_series[:]

        else:
            ser_t   = time_series[lag_ind:]
            ser_t_l = time_series[:-lag_ind]

        data_mean = 0.0
        ser_t   = ser_t - data_mean
        ser_t_l = ser_t_l - data_mean

        sum_var = sum(ser_t * ser_t_l) / (total_data_points - lag_ind)
        acf_data[lag_ind] = sum_var #/ (data_square/(total_data_points - 0))

    return np.array(acf_data)

ax = plt.subplot(gs[2, 12:])
ax.spines.top.set_visible(False)
ax.spines.right.set_visible(False)


y_limit = [0.25, 1.0]
samples = 100

alpha = 0.6
main_eth = [-7]
main_delta = [0.94, 0.97, 1][:2]
transient_index = 50_000
gen_gap = 1
gen_gap_indices = np.arange(0, 200_000 + 1 - transient_index, gen_gap).astype(int)

maximum_lag = len(gen_gap_indices)
no_lag = 3500

for delta, p_ind in zip(main_delta, range(len(main_delta))):

    # ax = plt.subplot(1,2,p_ind*2 + 1)#gs[:, :])
    # ax.spines.top.set_visible(False)
    # ax.spines.right.set_visible(False)

    for eth in main_eth:
        # find_the_mean = [] 
        # all_data = []
        # for ind in range(samples):

        #     # pathToPick = '../../undestanding_fluctuations/figure_E/fig_E{}_a{}_d{}/data_{}'.format(eth, alpha, delta, ind)
        #     # pathToPick = '../../phase_trans_finner_newer/data/nn2000_mm0.0001_rr10_kk2000_al0.6_dl{}_et{}/data_{}'.format(delta, eth, ind)
        #     pathToPick = '../../autocorrelation/data/nn2000_mm0.0001_rr10_kk2000_al0.6_dl{}_et{}/data_{}'.format(delta, eth, ind)
        #     data_si_counts = np.genfromtxt(pathToPick + '/si_sc_counts.dat')
        #     data_si_counts = data_si_counts[transient_index:,:]
        #     data_si = data_si_counts[:,0]/2000
        #     data_si = data_si[gen_gap_indices]  # Take every 25th generation after transient
        #     # plt.plot(data_si_counts[:,-1]/25, data_si, '--', linewidth= 0.5, ms=2.0, label='SI region')
        #     all_data.append(data_si)
        #     # acorr = sm.tsa.acf(data_si, adjusted=True, nlags=no_lag)
        #     a_acf = acf(data_si, lag_size=no_lag)
        #     # print(a_acf)
        #     find_the_mean.append(a_acf)
        #     print(eth, delta, ind)

        # new_data = [np.array(each_data) - np.mean(all_data)**2 for each_data in find_the_mean]

        # # for each_data in find_the_mean:
        # #     print(each_data[:10], np.mean(all_data)**2)
        # #     # plt.plot(acorr, '-o', color='g', linewidth= 0.5, ms=ms1, label='mixed phase')
        # #     # ax.plot(a_acf, '-', linewidth= 1.0, ms=ms2, label=r'mixed phase ($E_{\mathrm{th}}=$'+ str(eth)+', $\delta=$'+ str(delta) + ')') # , color='g'
        # #     # ax.plot(np.array(each_data) - np.mean(all_data)**2 , '-', linewidth= 0.05, ms=ms2) # , color='g'
        # #     # plt.plot(data_si_counts[:,-1], data_si, '--', linewidth= 0.5, ms=2.0, label='SI region')

        # data_to_plot = np.mean(new_data, axis=0)/np.max(np.mean(new_data, axis=0))
        data_to_plot = np.genfromtxt('./data/autocorr_eth{}_alpha0.6_delta{}.dat'.format(eth, delta))
        ax.plot(data_to_plot, '-', linewidth= 1.5, ms=ms2)
        # print(eth, delta)
        # np.savetxt('autocorr_eth{}_alpha0.6_delta{}.dat'.format(eth, delta), data_to_plot, fmt='%.6f')

        # ax.plot([np.mean(all_data)**2]*no_lag , '-k', linewidth= 0.05, ms=ms2, label='Mean over all the runs')

    ax.set_yscale('log')
 
    # ax.grid(True, which='both', linestyle='--', linewidth=0.05)
    ax.set_title(Title[5], loc='left', fontweight='bold')

    # ax.set_xlabel(r'$\Delta t$ [generations] ($\times$' + str(gen_gap) + ')', fontsize=fontsizeX)
    ax.set_xlabel(r'$\Delta t$ [generations]', fontsize=fontsizeX)
    # ax.set_ylabel(r'$E_{(t, s)} (r_t * r_{t+\Delta t}) - E(r)^2$', fontsize=fontsizeX, labelpad=10)
    ax.set_ylabel(r'Autocorrelation', fontsize=fontsizeX, labelpad=4)
    

    # ax.tick_params(axis = 'x', which = 'minor', labelsize = fontticks)
    # ax.set_xticks(np.arange(0,3501,250), minor = True)
    # ax.tick_params(axis = 'x', which = 'major', labelsize = fontticks)
    # ax.set_xticks(np.arange(0,3501,1000), minor = False)

    # ax.tick_params(axis = 'y', which = 'major', labelsize = fontticks)
    # ax.set_yticks([0.1, 1.0], minor=False)

    # xmax_limit = no_lag + 1
    # if eth == -9:
    #     # ax.set_ylim(np.min(data_to_plot[:xmax_limit+1]) - , 1.005)
    #     ax.set_ylim(0.02 , 1.005)
    #     # ax.set_xlim(0, xmax_limit)
    #     ax.set_xlim(-50, 3625)

    ax.tick_params(axis = 'x', which = 'minor', labelsize = fontticks)
    ax.set_xticks(np.arange(0,3501,250), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize = fontticks)
    ax.set_xticks(np.arange(0,3501,500), minor = False)

    ax.tick_params(axis = 'y', which = 'major', labelsize = fontticks)
    ax.set_yticks([0.1, 1.0], minor=False)
    ax.tick_params(axis = 'y', which = 'minor', labelsize = fontticks-1)
    ax.set_yticks([0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0], minor=True)

    xmax_limit = no_lag + 1
    if eth == -7:
        # ax.set_ylim(np.min(data_to_plot[:xmax_limit+1]) - , 1.005)
        ax.set_ylim(0.2 , 1.005)
        # ax.set_xlim(0, xmax_limit)
        ax.set_xlim(-100, 3650)

ax.legend([r'$E_{\mathrm{th}}=-7, \delta=0.94$', \
           r'$E_{\mathrm{th}}=-7, \delta=0.97$', \
            r'$E_{\mathrm{th}}=-7, \delta=1.0$'], labelspacing=0.45, ncols=1, fontsize=8, frameon=False, loc='best')







# Samples = 25

def bin_Control(input_Var_1, input_Var_2, binSize):
    data_X, data_Y = input_Var_1, input_Var_2

    Check_Bin = [0]  # corresponds to first bin [0 - firstBinEnd)
    for i in range(int(np.max(data_X)/(2*binSize)) + 2):
        if i == 0:
            Check_Bin.append(Check_Bin[-1]+binSize)
        else:
            Check_Bin.append(Check_Bin[-1]+2*binSize)

    output_Bin_Data = []; center_Bin = []; bib_Interval = binSize

    for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
        current_Bin_Data = []
        for Key, Value in zip(data_X, data_Y):
            if Key >= bin1 and Key < bin2:
                current_Bin_Data.append(Value)
        if len(current_Bin_Data) != 0:
            output_Bin_Data.append(sum(current_Bin_Data))
        if len(current_Bin_Data) == 0:
            output_Bin_Data.append(0)

    center_Bin = (np.array(Check_Bin[:-1])+np.array(Check_Bin[1:]))/2
    center_Bin[0] = Check_Bin[0]

    return center_Bin, np.array(output_Bin_Data)/sum(np.array(output_Bin_Data))



bin_Size = 0.5
alpha, delta = 0.9, 0.9
main_path = '../../variable_ene_al_dl'
Color = ['b','r','g','k','m','y','b','r','g']
energyThreshold = [-10, -6, -5, -4, -3, -2][::-1]
#energyThreshold = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
all_paths = [main_path + '/fig_E'+str(eth) + '_a'+str(int(alpha*100))+'_d'+str(int(delta*100)) for eth in energyThreshold]

data_eth_2, data_eth_2_counts = [ 9., 10., 11., 12., 13., 14.], \
                                    [  37,  572, 1525, 1602,  553,   50]
data_eth_6, data_eth_6_counts = [ 1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 10., 11.,], \
                                    [   4,   50,  165,  345,  525,  761,  934, 1009,  777,  287,   34]
data_eth_10, data_eth_10_counts = [0., 1., 2., 3., 4., 5., 6.], \
                                    [  2, 171, 762, 762, 300,  67,  21]



data_eth_2, data_eth_2_counts = [ 9., 10., 11., 12., 13., 14.], \
                                     [  81,  998, 4150, 3792,  905,   74]
data_eth_3, data_eth_3_counts = [ 9., 10., 11., 12., 13., 14.], \
                                    [  69,  962, 3830, 3962, 1106,   71]
data_eth_4, data_eth_4_counts = [ 7.,  8.,  9., 10., 11., 12., 13., 14.], \
                                    [   6,  133,  903, 3159, 3555, 1883,  356,    5]
data_eth_5, data_eth_5_counts = [ 4.,  5.,  6.,  7.,  8.,  9., 10., 11., 12., 13.], \
                                    [   3,   18,  109,  840, 2194, 2942, 2282, 1280,  310,   22]
data_eth_6, data_eth_6_counts = [ 1.,  2.,  3.,  4.,  5.,  6.,  7.,  8.,  9., 10., 11., 12., 13.], \
                                    [   1,   20,   72,  287,  721, 1409, 2846, 2645, 1332,  482,  136,   43,    6]
data_eth_10, data_eth_10_counts = [0., 1., 2., 3., 4., 5., 6., 7.], \
                                    [  21, 2603, 4517, 2361,  367,   75,   44,   12]


all_x_data = [data_eth_2, data_eth_3, data_eth_4, data_eth_5, data_eth_6, data_eth_10]
all_y_data = [data_eth_2_counts, data_eth_3_counts, data_eth_4_counts, \
                data_eth_5_counts, data_eth_6_counts, data_eth_10_counts]



energyThreshold = [-10, -6, -2]
all_x_data = [data_eth_2, data_eth_6, data_eth_10][::-1]
all_y_data = [data_eth_2_counts, data_eth_6_counts, data_eth_10_counts][::-1]

ax = plt.subplot(gs[2, :10])
ax.spines.right.set_visible(False)
ax.spines.top.set_visible(False)

for eth, pathToPick, index_Color, x_data, y_data in zip(energyThreshold[:], all_paths, range(len(energyThreshold)), all_x_data, all_y_data):
    # data = np.genfromtxt(pathToPick + '/ipr_class_no.dat')

    # x_data, y_data = data[:,0], data[:,1]
    # x_data, y_data = bin_Control(x_data, y_data, bin_Size)

    if eth == -10:
        x_data, y_data = x_data[:], y_data[:]
    else:
        x_data, y_data = x_data, y_data

    x_data, y_data = np.array(x_data), np.array(y_data)/sum(y_data)

    y_not_zero = 0
    for each_y_data, each_y_data_in in zip(y_data, range(len(y_data))):
        if np.round(each_y_data, decimals=3) != 0:
            y_not_zero = each_y_data_in
            break

    for each_y_data, each_y_data_in in zip(y_data[::-1], list(range(len(y_data)))[::-1]):
        if np.round(each_y_data, decimals=3) > 0.001:
            y_last_non_zero = each_y_data_in + 1
            break

    if y_not_zero > 1:
        y_not_zero = y_not_zero - 1

    if eth == -10 or eth == -8:
        y_not_zero = 2

    y_not_zero = 0

    # print (x_data[y_not_zero:], y_data[y_not_zero:])

    # y_not_zero, y_last_non_zero = 0, len(y_data)
    # ax.plot(x_data[y_not_zero:y_last_non_zero], y_data[y_not_zero:y_last_non_zero], '-o', markersize=3.5, linewidth=0.5, color=Color[index_Color], label=r'$E_{\mathrm{th}}$='+'{}'.format(eth))
    # plt.fill_between(x_data[y_not_zero:y_last_non_zero], -0.015, y_data[y_not_zero:y_last_non_zero], color=Color[index_Color], edgecolor='w', alpha=0.15)
    

    ax.plot(x_data[y_not_zero:y_last_non_zero], y_data[y_not_zero:y_last_non_zero], '-o', markersize=3.5, linewidth=0.5, color=Color[index_Color], label=r'$E_{\mathrm{th}}$='+'{}'.format(eth))
    plt.fill_between(x_data[y_not_zero:y_last_non_zero], -0.015, y_data[y_not_zero:y_last_non_zero], color=Color[index_Color], edgecolor='w', alpha=0.15)
    index_max = np.argmax(y_data) if np.argmax(y_data) != 0 else 1
    ax.plot([x_data[index_max]]*2, [-0.01, y_data[index_max]], '--', markersize=2, linewidth=0.5, color=Color[index_Color])


ax.tick_params(axis = 'x', which = 'minor', labelsize = fontticks)
ax.set_xticks(np.arange(0,15,1), minor = True)
ax.tick_params(axis = 'x', which = 'major', labelsize = fontticks)
ax.set_xticks(np.arange(0,16,5), minor = False)

ax.tick_params(axis = 'y', which = 'minor', labelsize = fontticks)
ax.set_yticks(np.arange(0.0,0.61,0.05), minor = True)
ax.tick_params(axis = 'y', which = 'major', labelsize = fontticks)
ax.set_yticks([0.0, 0.2, 0.4, 0.6], minor = False)
                                               
ax.set_ylabel(r'Fraction', fontsize=fontsizeY, labelpad=9)
ax.set_xlabel(r'Effective class number, $K$', fontsize=fontsizeX)
#plt.text(1, 0.145, r'p(1-5)={}'.format(0.0), fontsize=8, alpha=0.85)
ax.legend(ncol=3, loc='center', bbox_to_anchor=[0.63, 0.95], fontsize=fontticks, frameon=False)
ax.set_title('{}'.format(Title[4]), loc='left', fontweight="bold")
ax.set_xlim(-0.25,15.25)
ax.set_ylim(-0.0075,0.5)






#plt.tight_layout()
#plt.savefig('./figures/fig_std_class_no_heat_map.pdf', dpi=600)
plt.savefig('./figures/fig_4.pdf')
# plt.show()
plt.close()


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
