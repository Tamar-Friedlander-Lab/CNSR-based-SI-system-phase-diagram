#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
#from numba import jit # type: ignore
import pickle
import glob
#from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import seaborn as sns # type: ignore
import matplotlib as mpl # type: ignore
import statsmodels.api as sm # type: ignore
import matplotlib.gridspec as gridspec
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

def si_line(class_no, alpha, A2): return 0.5 + (1 - A2)/(2*alpha*(class_no - 1 + A2))

energy_variable = [-10, \
                -9.75, -9.5, -9.25, -9, \
                    -8.75, -8.5, -8.25, -8, \
                        -7.75, -7.5, -7.25, -7, \
                            -6.75, -6.5, -6.25, -6, \
                                -5.75, -5.5, -5.25, -5, \
                                    -4.75, -4.5, -4.25, -4, \
                                        -3.75, -3.5, -3.25, -3, \
                                            -2.75, -2.5, -2.25, -2]

# energy_variable = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
delta_variable = [np.round(t_delta, decimals=2) for t_delta in np.arange(0.75, 1.01, 0.01)]
energy_variable = np.array(energy_variable[:])
delta_variable = np.array(delta_variable[:])

#class_data = np.genfromtxt('./class_no_copied_from_phase_trans_finner.dat')
class_data = np.genfromtxt('./data/class_number_main_fix_k=1.dat')
std_class_data = np.genfromtxt('./data/cv_class_number_main_fix_k=1.dat')
# print(class_data, list(class_data[:,19]), np.shape(class_data))


# for i in range(5):
#     class_data[i, 19] = 0.0

# for i in range(5):
#     print(class_data[i, 19])



fig = plt.figure(figsize=(7.5, 6.0))
#fig, axes = plt.subplots(3, 1, figsize=(4.25, 10.0), gridspec_kw={'width_ratios': [1.0], 'height_ratios': [3.5, 3.5, 2.5]})
gs = gridspec.GridSpec(2, 22,  height_ratios=[1, 1], width_ratios= [1 for _ in range(22)])
plt.subplots_adjust(top=0.962, bottom=0.082, left=0.071, right=0.9925, hspace=0.400, wspace=1.000)
fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 7
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0


# [ 9. 10. 11. 12. 13. 14.] [  37  572 1525 1602  553   50]
# [ 1.  2.  3.  4.  5.  6.  7.  8.  9. 10. 11.] [   4   50  165  345  525  761  934 1009  777  287   34]
# [0. 1. 2. 3. 4. 5. 6.] [  2 171 762 762 300  67  21]

cmap = sns.color_palette("coolwarm", as_cmap=True)
#ax1 = plt.subplot(3,1,1)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[1,:10])
# class_data_to_plot = np.concatenate((np.zeros((33, 25)), class_data), axis=1)
# print(class_data)
class_data = class_data[::-1]
# print('Class number avg min, max:', np.min(class_data), np.max(class_data))
class_data = np.concatenate((np.zeros((len(energy_variable), 11)), class_data[:, 6:]), axis=1)
data_to_remove = []
for i in range(33):
    for j in range(26):
        if class_data[i, j] < 1.0:
            data_to_remove.append([i, j])
            class_data[i, j] = 0
ax = sns.heatmap(class_data, cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, cbar_kws={"ticks": [i for i in range(0,17,2)],\
                    'label':r'mean effective class number, $\langle K \rangle$',\
                    'shrink':1.00},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)



temp_energy_variable = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2])
temp_temp_energy_variable = np.array([-10, -9.75, -9, -8, -7, -6, -5, -4, -3, -2])
line_sc = [0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75]
line_si = [0.75, 0.72, 0.66, 0.63, 0.6, 0.6, 0.6, 0.6, 0.6]

# ax.plot([tx/0.03 + 0.5 for tx in line_sc], [0.5+(ty+10)/0.25 for ty in temp_temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
# ax.plot([tx/0.03 + 1.5 for tx in line_si], [0.5+(ty+10)/0.25 for ty in temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)


circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87] # taking maximum average number of classes over different deltas
# classes_number  = [3.80, 4.3, 5.20, 7.1, 8.96, 9.81, 10.90, 1.0, 1.0]# taking maximum average number of classes over different deltas 
# for each_class in classes_number:
#     if each_class != 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.1))
#     if each_class == 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.9))

circles_sc_si_to_plot = [13, 13, 13, 18, 25]
# classes_number = [1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
# for each_class in classes_number:
#     circles_sc_si_to_plot.append(si_line(each_class, 0.6, 0.9))

# print('\n')
# print(circles_sc_si_to_plot)
# print(energy_variable)
#sns.lineplot(x=circles_to_plot1, y=energy_variable[:-2])#, color=mcolors.TABLEAU_COLORS['tab:gray'])
#sns.lineplot(x=circles_sc_si_to_plot, y=np.array(list(range(len(energy_variable))))+1.0, palette='r')#, color=mcolors.TABLEAU_COLORS['tab:red'])

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
# ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
# ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')

ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 19.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w',rotation=90)
ax.text(14.5, 15, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(12.0, 28, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('c', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)


#plt.tight_layout()
#plt.savefig('./figures/fig_class_no_heat_map.pdf', dpi=600)
#plt.show()
#plt.close()











# fig = plt.figure(figsize=(4.75,3.75))
# plt.subplots_adjust(top=0.993, bottom=0.153, left=0.119, right=1.036, hspace=0.5, wspace=0.0)
# fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0

#cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.diverging_palette(250, 0, l=45, center="light", as_cmap=True)
#ax1 = plt.subplot(3,1,2)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[1,12:])
# data_to_plot = np.divide(std_class_data, class_data, out=np.zeros_like(std_class_data), where=class_data!=0)
data_to_plot = std_class_data[::-1]
data_to_plot = np.concatenate((np.zeros((len(energy_variable), 11)), data_to_plot[:, 6:]), axis=1)
for index_i in data_to_remove:
    data_to_plot[index_i[0], index_i[1]] = 0

# print('Class number CV min, max:', np.min(data_to_plot), np.max(data_to_plot))
ax = sns.heatmap(data_to_plot, cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, \
                    vmax=0.6, vmin=0.0, \
                    cbar_kws={"ticks": [i/10 for i in range(0,40,1)],\
                    'label':r'effective class number CV',\
                    'shrink':1.0},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
# ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
# ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')

ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 19.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w',rotation=90)
ax.text(14.5, 15, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(12.0, 28, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('d', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)























#class_data = np.genfromtxt('./class_no_copied_from_phase_trans_finner.dat')
class_data = np.genfromtxt('./data/si_avg_data_main_fix_k=1.dat')
std_class_data = np.genfromtxt('./data/si_std_data_main_fix_k=1.dat')
# print(class_data, list(class_data[:,19]), np.shape(class_data))


cmap = sns.color_palette("coolwarm", as_cmap=True)
#ax1 = plt.subplot(3,1,1)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[0,:10])
# data_to_plot = np.concatenate((np.zeros((9, 5)), data_to_plot[:, :]), axis=1)
# class_data_to_plot = np.concatenate((np.zeros((33, 25)), class_data), axis=1)
# print(class_data)
class_data = class_data[::-1]
class_data = np.concatenate((np.zeros((len(energy_variable), 11)), class_data[:, 6:]), axis=1)
# print('SI fraction avg min, max:', np.min(class_data), np.max(class_data))
ax = sns.heatmap(class_data, cmap=cmap, rasterized=True, \
                    vmax=1.0, vmin=0.0, \
                    cbar=True, ax=ax_to_plot, cbar_kws={"ticks": [np.round(i/5, 2) for i in range(6)],\
                    'label':r'mean SI fraction',\
                    'shrink':1.00},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)



temp_energy_variable = np.array([-10, -9, -8, -7, -6, -5, -4, -3, -2])
temp_temp_energy_variable = np.array([-10, -9.75, -9, -8, -7, -6, -5, -4, -3, -2])
line_sc = [0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75, 0.75]
line_si = [0.75, 0.72, 0.66, 0.63, 0.6, 0.6, 0.6, 0.6, 0.6]

# ax.plot([tx/0.03 + 0.5 for tx in line_sc], [0.5+(ty+10)/0.25 for ty in temp_temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
# ax.plot([tx/0.03 + 1.5 for tx in line_si], [0.5+(ty+10)/0.25 for ty in temp_energy_variable][::-1], '-', color='k', linewidth=0.75)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)


circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87] # taking maximum average number of classes over different deltas
# classes_number  = [3.80, 4.3, 5.20, 7.1, 8.96, 9.81, 10.90, 1.0, 1.0]# taking maximum average number of classes over different deltas 
# for each_class in classes_number:
#     if each_class != 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.1))
#     if each_class == 1.0:
#         circles_to_plot1.append(si_line(each_class, 0.6, 0.9))

circles_sc_si_to_plot = [13, 13, 13, 18, 25]
# classes_number = [1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
# for each_class in classes_number:
#     circles_sc_si_to_plot.append(si_line(each_class, 0.6, 0.9))

# print('\n')
# print(circles_sc_si_to_plot)
# print(energy_variable)
#sns.lineplot(x=circles_to_plot1, y=energy_variable[:-2])#, color=mcolors.TABLEAU_COLORS['tab:gray'])
#sns.lineplot(x=circles_sc_si_to_plot, y=np.array(list(range(len(energy_variable))))+1.0, palette='r')#, color=mcolors.TABLEAU_COLORS['tab:red'])

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
# ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
# ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')

ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 19.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w',rotation=90)
ax.text(14.5, 15, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(12.0, 28, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('a', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)


#plt.tight_layout()
#plt.savefig('./figures/fig_class_no_heat_map.pdf', dpi=600)
#plt.show()
#plt.close()











# fig = plt.figure(figsize=(4.75,3.75))
# plt.subplots_adjust(top=0.993, bottom=0.153, left=0.119, right=1.036, hspace=0.5, wspace=0.0)
# fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
AminoAcid = ['H', 'P', '+', '-']
color = ['b', 'b', 'b']
Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
tickswidth, tickssize = 0.35, 1.0

#cmap = sns.color_palette("coolwarm", as_cmap=True)
cmap = sns.diverging_palette(250, 0, l=45, center="light", as_cmap=True)
#ax1 = plt.subplot(3,1,2)

# cbar_kws = {"shrink":1,
#             'extend':'min', 
#             'extendfrac':.1, 
#             "drawedges":True, 
#             'ticks': [0.0, 0.2, 0.4, 0.5, 0.7, 0.8, 1.0], # set ticks of color bar
#             'label':'Color Bar'}
ax_to_plot = plt.subplot(gs[0,12:])
# data_to_plot = np.divide(std_class_data, class_data, out=np.zeros_like(std_class_data), where=class_data!=0)
data_to_plot = std_class_data[::-1]
data_to_plot = np.concatenate((np.zeros((len(energy_variable), 11)), data_to_plot[:, 6:]), axis=1)
# data_to_plot = np.concatenate((np.zeros((33, 12)), data_to_plot[:, 12:]), axis=1)
# for i, j in zip(range(33), range(26)):
#     if data_to_plot[i, j] >= 0.55:
#         # print(data_to_plot[i, j])
#         data_to_plot[i, j] = 0.55
# print('SI fraction STD min, max:', np.min(data_to_plot), np.max(data_to_plot))
ax = sns.heatmap(data_to_plot, cmap=cmap, rasterized=True, \
                    cbar=True, ax=ax_to_plot, \
                    vmax=0.47, vmin=0.0, \
                    cbar_kws={"ticks": [i/10 for i in range(6)],\
                    'label':r'SI fraction STD',\
                    'shrink':1.0},\
                    )#, linewidth=1.0)
ax.figure.axes[-1].tick_params(labelsize=6)
ax.figure.axes[-1].yaxis.label.set_size(fontsizeX-2)

circles_sc_si_to_plot = [14, 14, 14, 16, 18, 20, 22, 25]
# ax.plot([12]*len(circles_to_plot1), [0.5+(ty+10)/0.25 for ty in temp_energy_variable[::-1]], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
# ax.plot(circles_sc_si_to_plot, [0.5, 4.5, 8.5, 10.5, 12.5, 14.5, 15.5, 16.5], 'o', ms=3.5, color='k')

ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeX)
ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeY)

y_ticks = [energy_variable[::-1][ii] if ii in np.arange(0,33,4) else '' for ii in np.arange(0,33,1)]
x_ticks = [delta_variable[ii] if ii in [ 0,  5, 10, 15, 20, 25] else '' for ii in np.arange(0,26,1)]
ax.set_yticks(np.arange(0,33,1)+0.5, y_ticks, rotation='horizontal', fontsize=fontticks-1)
ax.set_xticks(np.arange(0,26,1)+0.5, x_ticks, rotation=90, fontsize=fontticks-1)
#ax.tick_params(top=True, labeltop=True, bottom=True, labelbottom=True, right=True, labelright=True)

ax.text(2.5, 19.5, 'Self-\ncompatible', fontsize=8, fontweight='bold', color='w',rotation=90)
ax.text(14.5, 15, 'Self-\nincompatible', fontsize=8, fontweight='bold', color='w')
ax.text(12.0, 28, 'Mixed', fontsize=8, fontweight='bold', color='w')

ax.set_title('b', loc='left', fontweight='bold')
# ax.set_title(r'self pollination rate, $\alpha=0.60$', loc='right', fontsize=7)


#plt.tight_layout()
#plt.savefig('./figures/fig_std_class_no_heat_map.pdf', dpi=600)
plt.savefig('./figures/fig_5.pdf')
# plt.show()
plt.close()







# from matplotlib.gridspec import GridSpec

# fig = plt.figure(figsize=(8,8))
# fig.suptitle("Controlling spacing around and between subplots")

# gs1 = GridSpec(3, 3, left=0.05, right=0.48, wspace=0.05)
# ax1 = fig.add_subplot(gs1[:-1, :])
# ax2 = fig.add_subplot(gs1[-1, :-1])
# ax3 = fig.add_subplot(gs1[-1, -1])

# gs2 = GridSpec(3, 3, left=0.55, right=0.98, hspace=0.05)
# ax4 = fig.add_subplot(gs2[:, :-1])
# ax5 = fig.add_subplot(gs2[:-1, -1])
# ax6 = fig.add_subplot(gs2[-1, -1])

#annotate_axes(fig)
#plt.show()








# flights = sns.load_dataset("flights")
# flights.head()
# may_flights = flights.query("month == 'May'")
# sns.lineplot(data=may_flights, x="year", y="passengers")

# plt.show()


# import matplotlib.pyplot as plt
# import pandas as pd

# sns.set_theme()

# # Load the brain networks example dataset
# df = sns.load_dataset("brain_networks", header=[0, 1, 2], index_col=0)
#print(df)

# # Select a subset of the networks
# used_networks = [1, 5, 6, 7, 8, 12, 13, 17]
# used_columns = (df.columns.get_level_values("network")
#                           .astype(int)
#                           .isin(used_networks))
# df = df.loc[:, used_columns]

# # Create a categorical palette to identify the networks
# network_pal = sns.husl_palette(8, s=.45)
# network_lut = dict(zip(map(str, used_networks), network_pal))

# # Convert the palette to vectors that will be drawn on the side of the matrix
# networks = df.columns.get_level_values("network")
# network_colors = pd.Series(networks, index=df.columns).map(network_lut)

# # Draw the full plot
# g = sns.clustermap(df.corr(), center=0, cmap="vlag",
#                    row_colors=network_colors, col_colors=network_colors,
#                    dendrogram_ratio=(.1, .2),
#                    cbar_pos=(.02, .32, .03, .2),
#                    linewidths=.75, figsize=(12, 13))
# g.ax_row_dendrogram.set_visible(False)
# ### HERE IS THE ISSUE
# g.ax_heatmap.xaxis.set_label_position('top')
# g.ax_heatmap.yaxis.set_label_position('left')
# ###
# g.fig.suptitle("Test the label on top", y=1.03,x=0.55)
# plt.plot()
# #plt.show()
# plt.savefig('heat_map_brain.pdf', dpi=600)
# plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
