#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt # type: ignore
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys # type: ignore
import collections, pickle
from datetime import datetime
# from numba import jit # type: ignore
import pickle
from scipy.optimize import curve_fit # type: ignore
import matplotlib.ticker as mtick # type: ignore
from operator import itemgetter
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
import matplotlib as mpl # type: ignore
import seaborn as sns # type: ignore
from matplotlib.ticker import FormatStrFormatter # type: ignore
import matplotlib.colors as mcolors  # type: ignore
import matplotlib as mpl # type: ignore
import matplotlib # type: ignore
# matplotlib.use('TKAgg') # alternate when qt.qpa.plugin: Could not find the Qt platform plugin "wayland" in ""
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)



def bin_Control(input_Var_1, input_Var_2, binSize):
    data_X, data_Y = input_Var_1, input_Var_2

    Check_Bin = [np.min(data_X)]  # corresponds to first bin [0 - firstBinEnd)
    for i in range(int((np.max(data_X) - np.min(data_X))/binSize) + 2):
        if Check_Bin[0] == 0:
            Check_Bin.append(Check_Bin[-1]+binSize)
        else:
            Check_Bin.append(Check_Bin[-1]+binSize)

    output_Bin_Data = []; center_Bin = []; bib_Interval = binSize

    for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
        current_Bin_Data = []
        for Key, Value in zip(data_X, data_Y):
            if Key >= bin1 and Key < bin2:
                current_Bin_Data.append(Value)
        if len(current_Bin_Data) != 0:
            output_Bin_Data.append(sum(current_Bin_Data))
        if len(current_Bin_Data) == 0:
            output_Bin_Data.append(0)

    center_Bin = (np.array(Check_Bin[:-1])+np.array(Check_Bin[1:]))/2
    center_Bin[0] = Check_Bin[0]

    return center_Bin, np.array(output_Bin_Data)/sum(np.array(output_Bin_Data))

def bin_Control(input_Var_1, input_Var_2, binSize):
    data_X, data_Y = input_Var_1, input_Var_2

    Check_Bin = [0]  # corresponds to first bin [0 - firstBinEnd)
    for i in range(int(np.max(data_X)/(2*binSize)) + 2):
        if i == 0:
            Check_Bin.append(Check_Bin[-1]+binSize)
        else:
            Check_Bin.append(Check_Bin[-1]+2*binSize)

    output_Bin_Data = []; center_Bin = []; bib_Interval = binSize

    for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
        current_Bin_Data = []
        for Key, Value in zip(data_X, data_Y):
            if Key >= bin1 and Key < bin2:
                current_Bin_Data.append(Value)
        if len(current_Bin_Data) != 0:
            output_Bin_Data.append(sum(current_Bin_Data))
        if len(current_Bin_Data) == 0:
            output_Bin_Data.append(0)

    center_Bin = (np.array(Check_Bin[:-1])+np.array(Check_Bin[1:]))/2
    center_Bin[0] = Check_Bin[0]

    return center_Bin, np.array(output_Bin_Data)/sum(np.array(output_Bin_Data))




weight = [0.5, 0.265, 0.113, 0.122]
def si_counts_fig(input_Var):


    # tot_population = 2000
    # each_alpha = 0.60
    # delta_s_e = [[], [], [], [], [], [], [], [], []]
    # delta_m_e = [[], [], [], [], [], [], [], [], []]
    # th_criteria_l = 0.11
    # th_criteria_h = 1 - th_criteria_l
    # main_path = '../../phase_transition_forward'

    # energy_variable = [-10, -9, -8, -7]
    # for eth, ind in zip(energy_variable, range(len(energy_variable))):
    #     delta_variable = [0.42, 0.45, 0.48, 0.51, 0.54, 0.57, 0.60, 0.63, 0.66, 0.69, 0.72, 0.75, 0.78, 0.81, 0.84, 0.87, 0.90]

    #     pick_path   = [main_path + '/figure_E/fig_E' + str(eth) + '_a'+str(int(np.round(each_alpha*100, 0)))+'_d'+str(int(np.round(each_delta*100, 0))) for each_delta in delta_variable]
    #     data = [np.genfromtxt(each_pick_path + '/si_counts.dat') for each_pick_path in pick_path]
    #     mean_data = [list(np.round(np.mean(each_data, axis=0), 0).astype(int)) for each_data in data]

    #     is_SC = False
    #     for each_mean_data, delta in zip(mean_data, delta_variable):

    #         if each_mean_data[0] >= tot_population*th_criteria_l and each_mean_data[0] <= tot_population*(th_criteria_h*1.00):
    #             delta_s_e[ind].append(delta)

    #         if each_mean_data[0] >= tot_population*th_criteria_h:
    #             delta_m_e[ind].append(delta)

    #     print (delta_s_e[ind])

    # energy_variable = [-6, -5, -4, -3, -2]
    # for eth, ind in zip(energy_variable, range(4, len(energy_variable)+4)):
    #     delta_variable = [0.42, 0.45, 0.48, 0.51, 0.54, 0.57, 0.60, 0.63, 0.66, 0.69, 0.72]

    #     pick_path   = [main_path + '/figure_E/fig_E' + str(eth) + '_a'+str(int(np.round(each_alpha*100, 0)))+'_d'+str(int(np.round(each_delta*100, 0))) for each_delta in delta_variable]
    #     data = [np.genfromtxt(each_pick_path + '/si_counts.dat') for each_pick_path in pick_path]
    #     mean_data = [list(np.round(np.mean(each_data, axis=0), 0).astype(int)) for each_data in data]

    #     is_SC = False
    #     for each_mean_data, delta in zip(mean_data, delta_variable):

    #         if each_mean_data[0] > tot_population*th_criteria_l and each_mean_data[0] < tot_population*(th_criteria_h*1.02):
    #             delta_s_e[ind].append(delta)

    #         if each_mean_data[0] >= tot_population*th_criteria_h:
    #             delta_m_e[ind].append(delta)

    #         #print (each_mean_data[0])

    #     print (delta_s_e[ind])
    # #print (delta_s_e)

    # print ('ok')



    energy_variable = [-10.25, -9, -8, -7, -6, -5, -4, -3, -1.75]
    delta_variable = [0.42, 0.45, 0.48, 0.51, 0.54, 0.57, 0.60, 0.63, 0.66, 0.69, 0.72, 0.75, 0.78, 0.81, 0.84, 0.87, 0.90]
    # line_sc, line_si = [], []
    # for each_delta_s, each_delta_i in zip(delta_s_e, delta_m_e):
    #     line_sc.append(each_delta_s[0] - 0.0)
    #     line_si.append(each_delta_s[-1] + 0.0)
    #     #line_si.append(each_delta_i[0] + 0.0)

    # print (line_sc)
    # print(line_si)
    # #def si_line(class_no, alpha, A2): return 0.5 + (1 - A2)/(2*alpha*(class_no - 1 + A2))
    # #classes_number = [2.0, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
    # #for each_class in classes_number:
    # #    print(si_line(each_class, 0.6, 0.80))

    # #fig = plt.figure(figsize=(8,3.0))
    f, (ax, ax1) = plt.subplots(1, 2, gridspec_kw={'width_ratios': [1.0, 1]}, figsize=(6.5,3.5))
    plt.subplots_adjust(top=0.9475, bottom=0.118, left=0.071, right=0.993, hspace=0.5, wspace=0.0)
    fontsizeX, fontsizeY, fonttitle, fontticks = 10, 10, 8, 8
    AminoAcid = ['H', 'P', '+', '-']
    color = ['b', 'b', 'b']
    Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'i', 'j', 'k','l','m', 'n'];
    tickswidth, tickssize = 0.35, 1.0



    #ax = plt.subplot(1,2,1)
    ax.spines.right.set_visible(False)
    ax.spines.top.set_visible(False)
    for axis in ['top','bottom','left','right']:    ax.spines[axis].set_linewidth(0.35)
    ax.tick_params(axis='both', which='both', width=tickswidth)

    # print (mcolors.TABLEAU_COLORS)
    # line_sc.insert(-2,0.57)
    # energy_variable.insert(-2,-3.25)
    # ax.plot(line_sc, energy_variable, '-', color='k', linewidth=0.25)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)
    # line_si.insert(-2,0.60)
    # ax.plot(line_si, energy_variable, '-', color='k', linewidth=0.25)# mcolors.TABLEAU_COLORS['tab:blue'], linewidth=0.75)

    # print(line_sc)
    # print(line_sc)
    alpha1 = 0.35; subs_value = -0.000


    # fill_1_y2 = list(energy_variable) + [-1.85]
    # fill_1_x  = line_sc  + [0]
    # fill_2_y2 = list(energy_variable)+list(energy_variable)[::-1]
    # fill_2_x  = line_sc+line_si[::-1]
    # fill_3_y2 = list(energy_variable) + [-1.85]
    # fill_3_x  = line_si  + [1]

    circles_sc_si_to_plot = np.array([12, 14, 14, 14, 16, 18, 20, 22, 26]).astype(int)
    circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87]
    ax.fill_between([0.75, 0.87], [-1, -1], -10.15, color=mcolors.TABLEAU_COLORS['tab:red'], alpha=alpha1, edgecolor="None")
    ax.fill_between(np.arange(0.75,1.05,0.01*1)[circles_sc_si_to_plot], [-1, -2.0, -3.0, -4.0, -4.5, -5.0, -5.5, -5.75, -6.0], -10.15, color=mcolors.TABLEAU_COLORS['tab:green'], alpha=alpha1, edgecolor="None")
    circles_sc_si_to_plot = np.array([14, 14, 14, 16, 18, 20, 22, 26]).astype(int)
    ax.fill_between(np.arange(0.75,1.05,0.01*1)[circles_sc_si_to_plot], [-2.0, -3.0, -4.0, -4.5, -5.0, -5.5, -5.75, -6.0], -1.15, color=mcolors.TABLEAU_COLORS['tab:blue'], alpha=alpha1, edgecolor="None")

    # print ('\n', '\n', '\n')
    # def sc_fitness(alpha, delta):   return 0.5 + (1-alpha)/2 + alpha*(1-delta)
    # def si_fitness(k):  return (k-1)*0.5/k + 0.5
    # def sc_mixed(fra, alpha): return 0.5 + (1 - fra)/(2*alpha)
    # def si_line(class_no, alpha, A2): return 0.5 + (1 - A2)/(2*alpha*(class_no - 1 + A2))

    # class_no = np.array([3, 4, 5, 7, 9, 10, 12, 12, 12])
    # si_fit = si_fitness(class_no)

    # circles_to_plot = []
    # circles_sc_si_to_plot = []
    energy_variable = [-10, -9, -8, -7, -6, -5, -4, -3, -2]
    # for each_class_no in class_no:
    #     si_fit = si_fitness(each_class_no)
    #     for delta in np.arange(0.6,0.95,0.01):
    #         if si_fit > sc_fitness(0.6, delta):
    #             circles_to_plot.append(delta)
    #             break

    # for fra in [0.9]*len(energy_variable):
    #     circles_sc_si_to_plot.append(sc_mixed(fra, 0.6))

    # circles_to_plot1 = []
    # classes_number = [3.28, 3.7, 4.76, 6.7, 8.64, 10.31, 11.09, 11.29, 10.67]
    # classes_number = [4.0, 4.5, 5.5, 6.7, 8.64, 10.31, 12.09]#, 9.0, 9.0]
    # classes_number = [3.15, 3.72, 4.76, 6.74, 8.96, 9.81, 10.93]#, 11.1, 10.9] # original from simulation
    # classes_number = [3.8, 4.1, 5.2, 6.74, 8.96, 9.81, 10.93]#, 11.1, 10.9]
    # classes_number  = [3.80, 4.3, 5.20, 7.1, 8.96, 9.81, 10.90]# taking maximum average number of classes over different deltas 
    # #classes_number = [3.75, 4, 5, 6, 7, 8, 9, 9, 9]
    # for each_class in classes_number:
    #     circles_to_plot1.append(si_line(each_class, 0.6, 0.1))


    # circles_sc_si_to_plot = []
    # classes_number = [1.53,1.96,2.29,2.13,3.01,3.16,4.03,1.0,1.0]
    # classes_number = [1.45,1.45,1.45,1.45,1.45,1.45,1.45,1.0,1.0]
    # classes_number = [1.5, 1.3, 1.72, 1.17, 1.64, 1.8, 1.79, 1.0, 1.0]
    # classes_number = [1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.56, 1.0, 1.0]
    # for each_class in classes_number:
    #     circles_sc_si_to_plot.append(si_line(each_class, 0.6, 0.9))

    #ax.plot(circles_to_plot, energy_variable, 'o', ms=3.5, color=mcolors.TABLEAU_COLORS['tab:blue'])
    # ax.plot(circles_to_plot1, energy_variable[:-2], 'o', ms=3.5, color=mcolors.TABLEAU_COLORS['tab:gray'])
    # ax.plot(circles_sc_si_to_plot, energy_variable, 'o', ms=2.5, color=mcolors.TABLEAU_COLORS['tab:red'])
    circles_sc_si_to_plot = np.array([14, 14, 14, 16, 18, 20, 22, 25]).astype(int)
    circles_to_plot1 = [0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87, 0.87]
    ax.plot(circles_to_plot1, energy_variable[::-1], 'o', ms=3.5, color='k')#, color=mcolors.TABLEAU_COLORS['tab:red'])
    ax.plot(np.arange(0.75,1.01,0.01*1)[circles_sc_si_to_plot], [-2.0, -3.0, -4.0, -4.5, -5.0, -5.5, -5.75, -6.0], 'o', ms=3.5, color='k')

    # print (circles_to_plot1)

    #ax.set_title(r'(IPR)', fontsize=fontsizeX-2, x=0.765, y=-0.285)
    #ax.set_ylabel('Fraction', fontsize=fontsizeY)

    ax.tick_params(axis = 'x', which = 'minor', labelsize = 0, top=True)
    ax.set_xticks(np.arange(0.75,1.01,0.01*1), minor = True)
    ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks, top=True)
    ax.set_xticks(np.arange(0.75,1.01,0.05), minor = False)

    #ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
    #ax.set_yticks(np.arange(-9.0,-1.0,2), [-9, -7, -5, -3], minor = True)
    ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax.set_yticks(np.arange(-10.0,-1.0,1), minor = False)

    #ax.text(0.03, -5.0, 'self-compatible', fontsize=fontsizeX+2, color=mcolors.TABLEAU_COLORS['tab:red'])
    #ax.text(0.557, -9.5, 'mixed', fontsize=fontsizeX+2, color=mcolors.TABLEAU_COLORS['tab:green'])
    #ax.text(0.66, -9.0, 'self-incompatible', fontsize=fontsizeX+2, color=mcolors.TABLEAU_COLORS['tab:blue'], rotation = -65)

    ax.set_xlabel(r'Inbreeding depression, $\delta$', fontsize=fontsizeX)
    ax.set_ylabel(r'Promiscuity, $E_{\mathrm{th}}$', fontsize=fontsizeY, labelpad=-2.5)
    # ax.set_title(r'Self-pollination rate, $\alpha$=0.60', loc='center', fontsize=fontsizeX-2)
    ax.set_title(Title[0], loc='left', fontweight='bold')

    ax.set_ylim([-10.10, -1.90])
    ax.set_xlim([0.75, 1.0025])


    ax2 = ax.twinx()
    #ax1.spines.right.set_visible(False)
    #ax1.spines.top.set_visible(False)
    for axis in ['top','bottom','left','right']:    ax2.spines[axis].set_linewidth(0.35)
    ax2.tick_params(axis='both', which='both', width=tickswidth)

    #ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
    #ax1.set_yticks([1, 3, 5, 7], [4, 7, 10, ''], minor = True)
    ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
    ax2.set_yticks([0, 1, 2, 3, 4, 5, 6, 7, 8], [2, 3, 4, 5, 7, 9, 11, 12, 12], minor = False)

    ax2.set_ylim([0, 8.0])
    #ax2.set_ylabel(r'Class number, $\langle K(E_{\mathrm{th}}) \rangle$', fontsize=fontsizeY)
    ax2.set_ylabel(r'Effective class number, $K(E_{\mathrm{th}})$', fontsize=fontsizeY)



    for axis in ['top','bottom','left','right']:
        ax1.spines[axis].set_visible(False)
    ax1.set_xticks([])
    ax1.set_yticks([])







    # class_no_on_phase_transition = [[] for i in range(9)]
    # class_no_on_phase_transition_delta =  [[] for i in range(9)]

    # bin_Size = 0.5
    # alpha = 0.60
    # energyThreshold = [-10, -9, -8, -7]
    # delta_variable  = [[0.90, 0.87, 0.84, 0.81, 0.78, 0.75][::-1],\
    #                    [0.90, 0.87, 0.84, 0.81, 0.78, 0.75, 0.72][::-1],\
    #                    [0.90, 0.87, 0.84, 0.81, 0.78, 0.75, 0.72, 0.69, 0.66][::-1],\
    #                    [0.90, 0.87, 0.84, 0.81, 0.78, 0.75, 0.72, 0.69, 0.66, 0.63][::-1]]

    # for eth_temp, ind in zip(energyThreshold, range(4)):
    #     for delta in delta_variable[ind]:
    #         pathToPick = '../../phase_transition_forward/figure_E/fig_E' + str(eth_temp) + '_a'+str(int(np.round(alpha*100, 0)))+'_d'+str(int(np.round(delta*100, 0)))
    #         data = np.genfromtxt(pathToPick + '/ipr_class_no.dat')

    #         x_data, y_data = data[:,0], data[:,1]/sum(data[:,1])
    #         #x_data, y_data = bin_Control(x_data, y_data, bin_Size)
    #         #print (np.round(sum(x_data*y_data), decimals=2))
    #         #index_max = np.argmax(y_data) if np.argmax(y_data) != 0 else 1
    #         class_no_on_phase_transition[eth_temp+10].append(np.round(sum(x_data*y_data), decimals=1))
    #         class_no_on_phase_transition_delta[eth_temp+10].append(delta)
    #         #print (x_data[index_max])


    # energyThreshold = [-6, -5, -4, -3, -2]
    # delta_variable  = [0.60, 0.63, 0.66, 0.69, 0.72]#[::-1]

    # for eth_temp in energyThreshold:
    #     for delta in delta_variable:

    #         if delta == 0.57 and eth_temp in [-2, -3]:
    #             class_no_on_phase_transition[eth_temp+10].append(0)
    #             class_no_on_phase_transition_delta[eth_temp+10].append(delta)
    #         else:
    #             pathToPick = '../../phase_transition_forward/figure_E/fig_E' + str(eth_temp) + '_a'+str(int(np.round(alpha*100, 0)))+'_d'+str(int(np.round(delta*100, 0)))
    #             data = np.genfromtxt(pathToPick + '/ipr_class_no.dat')

    #             x_data, y_data = data[:,0], data[:,1]/sum(data[:,1])
    #             #x_data, y_data = bin_Control(x_data, y_data, bin_Size)

    #             #index_max = np.argmax(y_data) if np.argmax(y_data) != 0 else 1
    #             class_no_on_phase_transition[eth_temp+10].append(np.round(sum(x_data*y_data), decimals=1))
    #             class_no_on_phase_transition_delta[eth_temp+10].append(delta)
    #             #print (x_data[index_max])

    # #print (class_no_on_phase_transition)



    # for eth, class_number, delta in zip(energy_variable, class_no_on_phase_transition, class_no_on_phase_transition_delta):
    #     #print (eth, class_number)
    #     #plt.plot(class_number, [eth]*len(class_number), '-')
    #     for delta_b, class_b in zip(delta, class_number):
    #         #ax.text(delta_b-0.005, eth-0.05, int(class_b), fontsize=3)
    #         'do nothing'













    each_alpha = 0.60
    energy_variable = [-3]
    delta_variable = [0.95]
    main_path = './data/'
    pick_path = [main_path + 'nn1000_mm0.0001_rr10_kk1000_al0.6_dl{}_et{}'.format(each_delta, eth) for eth in energy_variable for each_delta in delta_variable]
    energy_variable = [-6]
    delta_variable = [0.93, 0.75]
    for eth in energy_variable:
        for each_delta in delta_variable:
            pick_path.append(main_path + 'nn1000_mm0.0001_rr10_kk1000_al0.6_dl{}_et{}'.format(each_delta, eth))

    data = [[np.genfromtxt(each_pick_path + '/data_{}'.format(i) + '/si_sc_counts.dat') for i in [0]] for each_pick_path in pick_path]
    regimes = ['self-incompatible', 'mixed', 'self-compatible']
    colors = ['tab:blue', 'tab:green', 'tab:red']

    for each_data, plot_ind in zip(data, range(len(data))):

        ax = plt.subplot(3,3,(plot_ind)*3 + 3)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        for axis in ['top','bottom','left','right']:    ax.spines[axis].set_linewidth(0.35)
        ax.tick_params(axis='both', which='both', width=tickswidth)


        if plot_ind in [0, 1]:
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-2)
            ax.set_xticks([0, int(len(each_data[0])/2), len(each_data[0])], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-2)
            #ax.set_xticks([0, int(len(each_data[0])/4), int(len(each_data[0])/2), 3*int(len(each_data[0])/4), len(each_data[0])], [0, 25, 50, 75, 100], minor = False)
            ax.set_xticks([], minor = False)

        if plot_ind in [0, 1]:
            ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
            ax.set_xticks(np.linspace(0, len(each_data[0])-1, 9), minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-2)
            ax.set_xticks([0, int(len(each_data[0])/4), int(len(each_data[0])/2), int(len(each_data[0])/2)+int(len(each_data[0])/4), len(each_data[0])-1], [0, 50, 100, 150, 200], minor = False)

        if plot_ind in [2]:
            ax.tick_params(axis = 'x', which = 'minor', labelsize=0)
            ax.set_xticks(np.linspace(0, len(each_data[0])-1, 9), minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks-2)
            ax.set_xticks([0, int(len(each_data[0])/4), int(len(each_data[0])/2), int(len(each_data[0])/2)+int(len(each_data[0])/4), len(each_data[0])-1], [0, 50, 100, 150, 200], minor = False)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks-2)
        #ax.set_yticks(np.arange(0,1.01,0.2), minor = False)

        for each_each_data in each_data:
            print (len(each_each_data))
            ax.plot(range(len(each_each_data)), each_each_data[:,0]/1000, '-', color=mcolors.TABLEAU_COLORS[colors[plot_ind]], linewidth=1.0, ms=5, alpha=1.0)
            #ax.plot(each_each_data[:,-1], each_each_data[:,0]/1000, '-', color=mcolors.TABLEAU_COLORS[colors[plot_ind]], linewidth=1.0, ms=5, alpha=1.0)


        if plot_ind in [1]:
            ax.set_ylabel('Fraction of SI haplotypes', fontsize=fontsizeY-2)
            #ax.yaxis.set_label_coords(-0.14, 1.5)
        #ax.set_title(Title[plot_ind], fontsize=fontsizeX+6, loc='left', fontweight='bold')

        #ax.set_title(r'$E_{\mathrm{th}}$=' + str(energy_variable[0]) + r',  $\delta$=' + str(delta_variable[plot_ind]), fontsize=fontsizeX-3, loc='right')
        #ax.set_title('{}'.format(regimes[plot_ind]), fontsize=fontsizeX-3, loc='right')
        if plot_ind == 2: ax.set_xlabel(r'Generation $(\times 10^3)$', fontsize=fontsizeY-2, labelpad=7.8)
        if plot_ind == 0: ax.set_title('Evolutionary dynamics', fontsize=fontsizeX-2, loc='center')

        ax.set_ylim([-0.05, 1.05])
        if plot_ind in [0, 1]: ax.set_xlim([-50, 4075])
        if plot_ind == 2: ax.set_xlim([-50, 4075])



    #plt.tight_layout()
    plt.savefig('./figures/fig_phase_for_a60.pdf', transparent=True, dpi=1000)
    #plt.show()
    plt.close()

    return 'done'


print (si_counts_fig(0))


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
