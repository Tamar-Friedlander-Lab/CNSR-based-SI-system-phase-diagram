Python scripts for "Volatile but persistent co-existence of 
						self-compatibility and self-incompatibility"
						Amit Jangid
								
############################################################################

The order of running the scripts
	
	First, unzip the folder 'initial_pop.zip'

	1. modules/Module_Initial.py
	
		Any changes in the parameters should be done in the above scripts 
		such as population, mutation rate, how long is the transient time. 
		No need to run this file.


	2. main_sim_run.py
	
		This is the main script to generate the raw data. Before running 
		please make sure how many generations do you want the simulation to 
		run (to save the data) after transient time. This time is decided 
		at the bottom of the code in the list "after_end_sim". Transient 
		time is decided in the script "modules/Module_Initial.py" by the
		variable 'endsim'.
		
	3. input_folder_names.py
	
		This contains folder names in the folder 'data'. This picks the 
		path names from the file 'the_path.dat' (this file will be 
		generated when you run the script 'main_sim_run.py')
	
	
	4. main_merge_files.py
	
		This script merges different files into one file. Following are the 
		examples of different files merged into one type of file,
		
		'/aa_rnases_dict_*.pkl' ----->>> '/aa_rnases_dict.pkl'    
		'/aa_slfs_dict_*.pkl' ----->>> '/aa_slfs_dict.pkl'      
		'/e_rf_dict_*.pkl' ----->>> '/e_rf_dict.pkl'        
		'/hap_dict_*.pkl' ----->>> '/hap_dict.pkl' 
		
		after merging, it removes following files,
		'/aa_rnases_dict_*.pkl'   
		'/aa_slfs_dict_*.pkl'    
		'/e_rf_dict_*.pkl'       
		'/hap_dict_*.pkl'
	
	
		structure details of output data:
		
			aa_rnases_dict.pkl = {rnase_id_1: rnase sequence,
								  rnase_id_2: rnase sequence, ...
																}
																
		    aa_slfs_dict.pkl = {slf_id_1: slf sequence,
		    					slf_id_2: slf sequence, ...
		    												}
		    												
		    e_rf_dict.pkl = {(rnase_id, slf_id): total energy
		    												}
		    												
		    hap_dict.pkl = {hap_id_1: {rs_id: [rnase_id, slf1_id, 
		    												slf2_id, ...]
		    						   birth: birth time		
		    						   is_sc: 0 or 1
		    						   mutant: [is_rnase_mut, is_slf_mut]
		    						   }, ...
		    						   }
	
		    hap_count_dict.pkl = {time: [
		    							 [hap ids ...], 
		    							 [corresponding hap counts]
		    							 ], ...
		    							 }
		    							 
		    hap_count_inv_dict.pkl = {time: index to recreate 
		    												the population,
		    													...
		    							 						}
		    							 
		    mut_parents_rnase_dict.pkl = {offspring id: mutant parent id, 
		    													... }
		    							 
		    mut_parents_slf_dict.pkl = {offspring id: mutant parent id, ...
		    							 						}
		    							 
		    mut_parents_hap_dict.pkl = {offspring id: mutant parent id, ...
		    							 						}
	
	
	5. main_class_structure.py
	
		It provides the outcomes as dictionary with the following 
		structure,
		
		{time: {
				'class':{class_id_1: [classified hap ids ...], 
						 class_id_2: [...], ...
						 }, 
				
				'counts':{lass_id_1: [corresponding classified hap 
														ids counts ...], 
						  lass_id_2: [...], ...
						  }, 
				
				'not_in_class': [unclassified SI hap ids, .... 
								total unclassified SI counts, 
								total SC counts]
				}, 	
				... }
		
############################################################################
