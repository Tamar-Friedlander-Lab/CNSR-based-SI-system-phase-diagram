#                             Haploid model parameters - Structured population
###############################################################################################################
##########################################################################################
import numpy as np
import os
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################




class initialize:

    #             Haploid model initial parameters - Structured population
    ###############################################################################################################
    def parameters(input_Var):

        variable_eth = [-10,  -9.75,  -9.5,  -9.25,  -9,  -8.75,  -8.5,  -8.25, -8,  -7.75,  -7.5,  -7.25,  -7,  \
                        -6.75,  -6.5,  -6.25,  -6,  -5.75,  -5.5,  -5.25,  -5,  -4.75,  -4.5,  -4.25, -4,  \
                            -3.75,  -3.5,  -3.25,  -3,  -2.75,  -2.5,  -2.25, -2][:]
        
        variable_eth = [-10,  -9, -8,  -7,  -6,  -5,  -4,  -3,  -2][:]
        
        # variable_delta = [0.  , 0.03, 0.06, 0.09, 0.12, 0.15, 0.18, 0.21, 0.24, 0.27, 0.3 , 0.33, 0.36, 0.39, 0.42, 0.45, 0.48, 0.51, 0.54, 0.57, 0.585]
        # variable_delta = [0.78, 0.81, 0.84, 0.87, 0.9, 0.93, 0.96, 0.99] 
        # variable_delta = [0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1]

        variable_delta = [0.75, 0.76, 0.77, 0.78, 0.79, 0.8 , \
                            0.81, 0.82, 0.83, 0.84, 0.85, 0.86, 0.87, 0.88, 0.89, 0.9 , \
                               0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]

        # variable_delta = [0.85, 0.86, 0.87, 0.88, 0.89, 0.9 , \
        #                         0.91, 0.92, 0.93, 0.94, 0.95, 0.96, 0.97, 0.98, 0.99, 1]

        # variable_eth = [-2, -3, -4]
        # variable_delta = [0.87]
        

        #                  Haploid model initial parameters - Structured population
        ###############################################################################################################

        tot_length = int(len(variable_eth)*len(variable_delta))
        
        population = [1_000 for _ in range(tot_length)] # p_nn, population
        mutation =   [1e-4 for _ in range(tot_length)] # p_mm, mutation rate per amino acid (AA) per generation
        rnases =     [10 for _ in range(tot_length)] # p_rr, number of initial unique RNases
        attempts =   [1_000 for _ in range(tot_length)] # p_kk, number of attempts to find a partner
        alpha =      [0.6 for _ in range(tot_length)] # p_al, selfing rate
        delta =      [delta_ for _ in variable_eth for delta_ in variable_delta] # p_dl, inbreeding dipression
        ethreshold = [eth for eth in variable_eth for _ in variable_delta] # p_et, interaction energy threshold below which interaction is allowed
        length_rs =  [18 for _ in range(tot_length)] # p_le, number of amino acids (AAs) in each gene
        threshsc =   [0.8 for _ in range(tot_length)] # p_th, fraction of self-compatible haplotypes at which simulation stops
        startsim =   [0 for _ in range(tot_length)] # p_ss, generation to start from
        endsim =     [90_000 for _ in range(tot_length)] # p_es, upto this is considered transient time
        # endsim = startsim
        haps =       rnases # p_hh, number of intial unique haplotypes
        slfs =       [ele - 1 for ele in rnases] # p_s, number of initial SLFs on each haplotype


        #           Haploid model parameters main input for simulation - Structured population
        #                        islands = 1 makes panmictic population 
        ###############################################################################################################
        start_samples = 0
        end_samples = 5

        range_over_samples = list(range(start_samples, end_samples))

        population_main = [ele_in       for ele_in in population[:]              for _ in range_over_samples] # p_nn, population
        mutation_main =   [ele_in       for ele_in in mutation                   for _ in range_over_samples] # p_mm, mutation rate per amino acid (AA) per generation
        rnases_main =     [ele_in       for ele_in in rnases                     for _ in range_over_samples] # p_rr, number of initial unique RNases
        attempts_main =   [ele_in       for ele_in in attempts                   for _ in range_over_samples] # p_kk, number of attempts to find a partner
        alpha_main =      [ele_in       for ele_in in alpha                      for _ in range_over_samples] # p_al, selfing rate
        delta_main =      [ele_in       for ele_in in delta                      for _ in range_over_samples] # p_dl, inbreeding dipression
        ethreshold_main = [ele_in       for ele_in in ethreshold                 for _ in range_over_samples] # p_et, interaction energy threshold below which interaction is allowed
        length_rs_main =  [ele_in       for ele_in in length_rs                  for _ in range_over_samples] # p_le, number of amino acids (AAs) in each gene
        threshsc_main =   [ele_in       for ele_in in threshsc                   for _ in range_over_samples] # p_th, fraction of self-compatible haplotypes at which simulation stops
        startsim_main =   [ele_in       for ele_in in startsim                   for _ in range_over_samples] # p_ss, generation to start from
        endsim_main =     [ele_in       for ele_in in endsim                     for _ in range_over_samples] # p_es, this is transient time
        haps_main =       rnases_main # p_hh, number of intial unique haplotypes
        slfs_main =       [ele - 1 for ele in rnases_main] # p_s, number of initial SLFs on each haplotype
        samples_main =    [sampleNo for ele_in in population for sampleNo in range_over_samples] # sampleNo



        # main folder for each parameter set ---------
        folder = ['data' + '/' + 'nn'+str(t_pop)+'_'+'mm'+str(t_mut)+'_'+'rr'+str(t_rnases)+\
                '_'+'kk'+str(t_attempts)+'_'+'al'+str(t_alpha)+'_'+'dl'+str(t_delta)\
                    +'_'+'et'+str(t_ethreshold) \
                        for t_pop, t_mut, t_rnases, t_attempts, t_alpha,\
                            t_delta, t_ethreshold \
                                in zip(population_main, mutation_main, rnases_main, \
                                        attempts_main, alpha_main, delta_main, \
                                        ethreshold_main)]


        # sub folder under main folder for each independent run ---------
        folder_main = [each_folder + '/data_{}'.format(sampleNo) for each_folder, sampleNo in zip(folder, samples_main)]

        if not os.path.exists('data'):
            os.mkdir('data')

        for dir_main in np.unique(folder):
            if not os.path.exists(dir_main):
                os.mkdir(dir_main)

        for dir_main in np.unique(folder_main):
            if not os.path.exists(dir_main):
                os.mkdir(dir_main)

        find_index = np.array([iix for iix in range(len(folder)) if iix % (end_samples - start_samples) == 0])
        folder = np.array(folder, dtype='object')[find_index]
        np.savetxt('./the_path.dat', folder, fmt='%s')

        return [population_main, mutation_main, rnases_main, \
                    attempts_main, alpha_main, delta_main, \
                        ethreshold_main, length_rs_main, threshsc_main, \
                            startsim_main, endsim_main, haps_main, slfs_main, \
                                samples_main, folder_main]



    ###############################################################################################################

###############
#############
###########
#########
#######
