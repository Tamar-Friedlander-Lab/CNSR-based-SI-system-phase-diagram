###############################################################################################################
##########################################################################################
import numpy as np # type: ignore
from termcolor import colored # type: ignore
import pickle as pkl # type: ignore
import os # type: ignore
import blosc # type: ignore
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################




class analysis:

    global energy_tab

    #
    #
    # energy_tab = np.array([[-1,   0,     0,     0   ],\
    #                         [0,  -0.75, -0.25, -0.25],\
    #                         [0,  -0.25,  1,    -1.25],\
    #                         [0,  -0.25, -1.25,  1   ]])

    # # interaction energy between two proteins
    # def energyOfProtein(rnase, slf):  return sum([energy_tab[x,y] for x, y in zip(rnase, slf)])

    energy_tab = { 0:{0:-1, 1:0,     2:0,     3:0    }, \
                   1:{0:0,  1:-0.75, 2:-0.25, 3:-0.25}, \
                   2:{0:0,  1:-0.25, 2:1,     3:-1.25}, \
                   3:{0:0,  1:-0.25, 2:-1.25, 3:1    }  }
    
    def energyOfProtein(rnase, slf):    return sum([energy_tab[x][y] for x, y in zip(rnase, slf)]) # type: ignore


    #
    #
    # finding unique counts
    def find_counts(input_Var, how_many):

        f_counts = [0 for _ in range(how_many)]
        for key in input_Var:
            f_counts[key] += 1

        return f_counts


    #
    #
    # smoothing the time series; moving average
    def smooth_time_series(input_Var, wind_size):

        output_Var = np.zeros(len(input_Var))
        tracker = 0
        for ind in range(len(input_Var)):

            if ind - wind_size >= 0:
                s_ind = ind-wind_size
                e_ind = s_ind + 2*wind_size + 1
                output_Var[ind] = np.mean(input_Var[s_ind:e_ind])

            else:
                s_ind = ind - tracker
                e_ind = wind_size + 1 + tracker
                output_Var[ind] = np.mean(input_Var[s_ind:e_ind])
                tracker += 1

        return output_Var


    #
    #
    # input is only a dictionary
    def unique_counts_from_dict(input_var):

        keys = np.array(list(input_var.keys()))
        counts = np.array(list(input_var.values()))

        sorted_ind = np.argsort(keys)

        keys = keys[sorted_ind]
        counts = counts[sorted_ind]

        return np.concatenate(([keys], [counts]), axis=0).T


    #
    #
    # find effective number / inverse participation ratio
    def find_ipr(input_Var):

        total_Sum = sum(input_Var)
        if total_Sum > 0:
            input_Var = np.array(input_Var)/total_Sum
            IPR = 1.0/sum(input_Var**2)
        else: 
            IPR = 0
        
        return IPR


    #
    #
    # finding Hamming distance between two sequences
    def h_distance(inputX, inputY):
        hDistance = 0
        for x, y in zip(inputX, inputY):
            if x != y: hDistance += 1
        return int(hDistance)

    #
    #
    # colored text
    def colored_text(input_text):
        return colored(input_text, 'white', 'on_black', ['bold'])


    #
    #
    # average and STD
    def avg_std(input_data):
        data = input_data

        if len(np.shape(data)) == 2:
            data_avg = np.sum(data[:,0]*data[:,1]/sum(data[:,1]))
            data_avg = np.round(data_avg, decimals=2)

            expection_x_2  =  np.sum((data[:,0]**2)*data[:,1]/sum(data[:,1]))
            data_std = np.sqrt(expection_x_2 - data_avg**2)

        if len(np.shape(data)) == 1:
            data_avg = np.round(data[0], decimals=2)
            data_std = np.sqrt(data[0]**2 - data_avg**2)
            # basically ZERO STD

        return [data_avg, data_std]

        
    #
    #
    # merging dict files into one
    def merge_dict(main_to_update, all_files_in_list):

        for each_file in all_files_in_list:

            compressed_pickle = open(each_file,'rb').read()
            depressed_pickle = blosc.decompress(compressed_pickle)
            data_dict = pkl.loads(depressed_pickle)
            main_to_update.update(data_dict)
            # data_dict = pkl.load(open(each_file, 'rb'))
            # all_keys = list(data_dict.keys())
            # for each_key in all_keys:
            #     main_to_update[each_key] = data_dict[each_key]

        return main_to_update

    #
    #
    # finding parameters value from main path
    def find_parms(input_path):

        path_to_pick = []

        pop_list = []
        mut_list = []
        rr_list = []
        kk_list = []
        al_list = []
        dl_list = []
        eth_list = []
        run_list = []

        # path to pick the data
        for each_path in input_path:

            hyp_ind = [ind for ele, ind in zip(each_path, range(len(each_path))) if ele == '_']
    
            pop_value = int(each_path[9:hyp_ind[0]])
            mut_value = float(each_path[hyp_ind[0]+3:hyp_ind[1]])
            rr_value = int(each_path[hyp_ind[1]+3:hyp_ind[2]])
            kk_value = int(each_path[hyp_ind[2]+3:hyp_ind[3]])
            al_value = float(each_path[hyp_ind[3]+3:hyp_ind[4]])
            dl_value = float(each_path[hyp_ind[4]+3:hyp_ind[5]])
            eth_value = float(each_path[hyp_ind[5]+3:])

            sub_directories = next(os.walk(each_path))[1]


            for each_sub in sub_directories:

                path_to_pick.append(each_path + '/' + each_sub)
                pop_list.append(pop_value)
                mut_list.append(mut_value)
                rr_list.append(rr_value)
                kk_list.append(kk_value)
                al_list.append(al_value)
                dl_list.append(dl_value)
                eth_list.append(eth_value)
                run_list.append(int(each_sub[5:]))


        # path to save the data
        path_to_save = []
        for each_path in path_to_pick:
            if not os.path.exists('analysis' + each_path[6:]):
                os.makedirs('analysis' + each_path[6:])
            path_to_save.append('analysis' + each_path[6:])

        # if ordered list/array over the data index
        # sorted_ind = np.argsort(np.array(run_list)).astype(int)
        # pop_list = np.array(pop_list)[sorted_ind]
        # mut_list = np.array(mut_list)[sorted_ind]
        # rr_list = np.array(rr_list)[sorted_ind]
        # kk_list = np.array(kk_list)[sorted_ind]
        # al_list = np.array(al_list)[sorted_ind]
        # dl_list = np.array(dl_list)[sorted_ind]
        # eth_list = np.array(eth_list)[sorted_ind]
        # run_list = np.array(run_list)[sorted_ind]
        # path_to_pick = np.array(path_to_pick, dtype='str')[sorted_ind]
        # path_to_save = np.array(path_to_save, dtype='str')[sorted_ind]

        return pop_list, mut_list, rr_list, kk_list, al_list, dl_list, eth_list, run_list, path_to_pick, path_to_save


    #
    #
    # finding parameters value from main path
    def find_parms_no_sub_directories(input_path):

        path_to_pick = []

        pop_list = []
        mut_list = []
        rr_list = []
        kk_list = []
        al_list = []
        dl_list = []
        eth_list = []

        # path to pick the data
        for each_path in input_path:

            hyp_ind = [ind for ele, ind in zip(each_path, range(len(each_path))) if ele == '_']
    
            pop_value = int(each_path[9:hyp_ind[0]])
            mut_value = float(each_path[hyp_ind[0]+3:hyp_ind[1]])
            rr_value = int(each_path[hyp_ind[1]+3:hyp_ind[2]])
            kk_value = int(each_path[hyp_ind[2]+3:hyp_ind[3]])
            al_value = float(each_path[hyp_ind[3]+3:hyp_ind[4]])
            dl_value = float(each_path[hyp_ind[4]+3:hyp_ind[5]])
            eth_value = float(each_path[hyp_ind[5]+3:])

            for _ in [0]:

                path_to_pick.append(each_path)
                pop_list.append(pop_value)
                mut_list.append(mut_value)
                rr_list.append(rr_value)
                kk_list.append(kk_value)
                al_list.append(al_value)
                dl_list.append(dl_value)
                eth_list.append(eth_value)


        # path to save the data
        path_to_save = []
        for each_path in path_to_pick:
            if not os.path.exists('analysis' + each_path[6:]):
                os.makedirs('analysis' + each_path[6:])
            path_to_save.append('analysis' + each_path[6:])

        return pop_list, mut_list, rr_list, kk_list, al_list, dl_list, eth_list, path_to_pick, path_to_save
    

    #
    #
    # controling the bin size and outcomes
    def bin_control(input_var_1, input_var_2, bin_size):
        data_X, data_Y = input_var_1, input_var_2

        check_bin = [0]  # corresponds to first bin [0 - firstBinEnd)
        for i in range(int(np.max(data_X)/(2*bin_size)) + 2):
            if i == 0:
                check_bin.append(check_bin[-1]+bin_size)
            else:
                check_bin.append(check_bin[-1]+2*bin_size)

        output_bin_data = []; center_bin = []
        for bin1, bin2, index in zip(check_bin[:-1], check_bin[1:], range(len(check_bin[1:]))):
            current_Bin_Data = []

            for Key, Value in zip(data_X, data_Y):
                if Key >= bin1 and Key < bin2:
                    current_Bin_Data.append(Value)

            if len(current_Bin_Data) != 0:
                output_bin_data.append(sum(current_Bin_Data))

            if len(current_Bin_Data) == 0:
                output_bin_data.append(0)

        center_bin = (np.array(check_bin[:-1])+np.array(check_bin[1:]))/2
        center_bin[0] = check_bin[0]

        data_x = center_bin
        data_y = np.array(output_bin_data)#/sum(np.array(output_bin_data))
        non_zero_data_y = np.where(data_y != 0)[0]

        data_x = data_x[non_zero_data_y]
        data_y = data_y[non_zero_data_y]

        return data_x, data_y

    #
    #
    # controling the bin size and outcomes
    def bin_control(input_var_1, input_var_2, bin_size):
        data_X, data_Y = input_var_1, input_var_2

        check_bin = [0]  # corresponds to first bin [0 - firstBinEnd)
        for i in range(int(np.max(data_X)/(2*bin_size)) + 2):
            if i == 0:
                check_bin.append(check_bin[-1]+bin_size)
            else:
                check_bin.append(check_bin[-1]+2*bin_size)

        output_bin_data = []; center_bin = []
        for bin1, bin2, index in zip(check_bin[:-1], check_bin[1:], range(len(check_bin[1:]))):
            current_Bin_Data = []

            for Key, Value in zip(data_X, data_Y):
                if Key >= bin1 and Key < bin2:
                    current_Bin_Data.append(Value)

            if len(current_Bin_Data) != 0:
                output_bin_data.append(sum(current_Bin_Data))

            if len(current_Bin_Data) == 0:
                output_bin_data.append(0)

        center_bin = (np.array(check_bin[:-1])+np.array(check_bin[1:]))/2
        center_bin[0] = check_bin[0]

        data_x = center_bin
        data_y = np.array(output_bin_data)#/sum(np.array(output_bin_data))
        non_zero_data_y = np.where(data_y != 0)[0]

        data_x = data_x[non_zero_data_y]
        data_y = data_y[non_zero_data_y]

        return data_x, data_y
    

    #
    #
    # finding distinct allele counts; in the simulation two different rnases/slfs can have same sequence
    def distinct_alleles(aa_id_seq, non_sc_ids, non_sc_ids_counts):

        distinct_ids_counts_for_ipr = {tuple(aa_id_seq[id_]):0 for id_ in non_sc_ids} # # distinct rnases (effective number)
        for id_, count_ in zip(non_sc_ids, non_sc_ids_counts):
            distinct_ids_counts_for_ipr[tuple(aa_id_seq[id_])] += count_

        return list(distinct_ids_counts_for_ipr.values())


    #
    #
    # finding distinct haplotype counts; in the simulation two different haplotype ids can have same sequence
    def distinct_haplotypes(aa_rnases, aa_slfs, non_sc_haps_as_rs_ids, non_sc_haps_counts):

        no_of_haplotypes = len(non_sc_haps_as_rs_ids)
        list_of_haplotypes = list(range(no_of_haplotypes))
        list_of_slfs_per_hap = list(range(1, 9+1))
        hap_sequences = [[0 for _i in range(10)] for _ in list_of_haplotypes]

        for r_ind, r_id in zip(list_of_haplotypes, non_sc_haps_as_rs_ids[:,0]):
            hap_sequences[r_ind][0] = aa_rnases[r_id]

        for r_ind, pollen_ids in zip(list_of_haplotypes, non_sc_haps_as_rs_ids[:,1:]):
            for c_ind, s_id in zip(list_of_slfs_per_hap, pollen_ids):
                hap_sequences[r_ind][c_ind] = aa_slfs[s_id]

        hap_sequences = np.array(hap_sequences)
        hap_sequences = hap_sequences.reshape((no_of_haplotypes, 180))

        distinct_ids_counts_for_ipr = {tuple(hap_seq_):0 for hap_seq_ in hap_sequences} # # distinct rnases (effective number)
        for hap_seq_, count_ in zip(hap_sequences, non_sc_haps_counts):
            distinct_ids_counts_for_ipr[tuple(hap_seq_)] += count_

        return list(distinct_ids_counts_for_ipr.values())


    #
    #
    # finding number of rnases interacting per slf
    def per_slf_rnase_partner(non_sc_slfs_ids, non_sc_slfs_ids_counts, \
                              non_sc_rnases_ids, rnase_ids_counts_contribution_in_ipr, \
                                e_rf, p_ethreshold):
        
        per_slf_rnase_ptnr = []
        for s_id, s_id_count in zip(non_sc_slfs_ids, non_sc_slfs_ids_counts):

            s_id_interacting_r_id_ipr = 0
            for r_id, r_id_ipr in zip(non_sc_rnases_ids, rnase_ids_counts_contribution_in_ipr):
                if e_rf[(r_id, s_id)] < p_ethreshold:
                    s_id_interacting_r_id_ipr += r_id_ipr

            per_slf_rnase_ptnr.append([s_id_interacting_r_id_ipr, s_id_count])

        return per_slf_rnase_ptnr



    #
    #
    # finding number of rnases fertilized by a single haplotype
    def per_hap_rnase_partner(non_sc_haps_as_rs_ids, non_sc_haps_counts, \
                              non_sc_rnases_ids, rnase_ids_counts_contribution_in_ipr, \
                                e_rf, p_ethreshold):

        per_hap_rnase_ptnr = []
        for hap_as_s_ids, hap_as_s_ids_counts in zip(non_sc_haps_as_rs_ids[:,1:], non_sc_haps_counts):

            hap_id_interacting_r_id_ipr = 0
            for r_id, r_id_ipr in zip(non_sc_rnases_ids, rnase_ids_counts_contribution_in_ipr):

                for s_id in hap_as_s_ids:
                    if e_rf[(r_id, s_id)] < p_ethreshold:
                        hap_id_interacting_r_id_ipr += r_id_ipr
                        break
            
            per_hap_rnase_ptnr.append([hap_id_interacting_r_id_ipr, hap_as_s_ids_counts])

        return per_hap_rnase_ptnr


    #
    #
    # finding number of slfs detoxifying a single rnase
    def per_rnase_slf_partner(non_sc_rnases_ids, non_sc_rnases_ids_counts, \
                              fun_non_sc_slfs_ids, fun_slf_ids_counts_contribution_in_ipr, \
                                e_rf, p_ethreshold):
        
        per_rnase_slf_ptnr = []
        for r_id, r_id_count in zip(non_sc_rnases_ids, non_sc_rnases_ids_counts):

            r_id_interacting_r_id_ipr = 0
            for s_id, s_id_ipr in zip(fun_non_sc_slfs_ids, fun_slf_ids_counts_contribution_in_ipr):
                if e_rf[(r_id, s_id)] < p_ethreshold:
                    r_id_interacting_r_id_ipr += s_id_ipr

            per_rnase_slf_ptnr.append([r_id_interacting_r_id_ipr, r_id_count])

        return per_rnase_slf_ptnr
    


    #
    #
    # finding number of haplotypes fertilizing a single rnase
    def per_rnase_hap_partner(non_sc_rnases_ids, non_sc_rnases_ids_counts, \
                              non_sc_haps_as_rs_ids, haps_counts_contribution_in_ipr, \
                                e_rf, p_ethreshold):
        
        per_rnase_hap_ptnr = []
        for r_id, r_id_count in zip(non_sc_rnases_ids, non_sc_rnases_ids_counts):

            r_id_interacting_hap_ipr = 0
            for hap_as_s_ids, hap_id_ipr in zip(non_sc_haps_as_rs_ids[:,1:], haps_counts_contribution_in_ipr):

                for s_id in hap_as_s_ids:
                    if e_rf[(r_id, s_id)] < p_ethreshold:
                        r_id_interacting_hap_ipr += hap_id_ipr
                        break
            per_rnase_hap_ptnr.append([r_id_interacting_hap_ipr, r_id_count])

        return per_rnase_hap_ptnr


    #
    #
    # decompressing the pickle file
    def decompressing_blosc(file_name):

        compressed_pickle = open(file_name,'rb').read()
        depressed_pickle = blosc.decompress(compressed_pickle)
        data = pkl.loads(depressed_pickle)

        return data

































    # def bin_Control(input_var_1, input_var_2, bin_size):
    #     data_X, data_Y = input_var_1, input_var_2

    #     check_bin = [np.min(data_X)]  # corresponds to first bin [0 - firstBinEnd)
    #     for i in range(int((np.max(data_X) - np.min(data_X))/bin_size) + 2):
    #         if check_bin[0] == 0:
    #             check_bin.append(check_bin[-1]+bin_size)
    #         else:
    #             check_bin.append(check_bin[-1]+bin_size)

    #     output_bin_data = []; center_bin = []

    #     for bin1, bin2, index in zip(check_bin[:-1], check_bin[1:], range(len(check_bin[1:]))):
    #         current_Bin_Data = []
    #         for Key, Value in zip(data_X, data_Y):
    #             if Key >= bin1 and Key < bin2:
    #                 current_Bin_Data.append(Value)
    #         if len(current_Bin_Data) != 0:
    #             output_bin_data.append(sum(current_Bin_Data))
    #         if len(current_Bin_Data) == 0:
    #             output_bin_data.append(0)

    #     center_bin = (np.array(check_bin[:-1])+np.array(check_bin[1:]))/2
    #     center_bin[0] = check_bin[0]

    #     return center_bin, np.array(output_bin_data)/sum(np.array(output_bin_data))





