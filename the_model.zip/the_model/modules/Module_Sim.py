#                             Haploid model parameters - Structured population
###############################################################################################################
##########################################################################################
from modules.Module_Main import Main_model as Model # type: ignore
from datetime import datetime
import numpy as np
import os
from decimal import Decimal
import psutil
# import sys
# import pickle
# import random as ra
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print('Starts|--------|', start_time)


#
#             Haploid model main simulation - Structured population
#
###########################################################################################
#
#
###############################################################################################################

def SI_Structured_Pop_Evo_Main(input_Var):
    start_time_1 = datetime.now()

    p_population, \
    p_mutation, \
    p_rnases, \
    p_attempts, \
    p_alpha, \
    p_delta, \
    p_ethreshold, \
    p_length_rs, \
    p_threshsc, \
    p_startsim, \
    p_endsim, \
    p_haps, \
    p_slfs, \
    p_samples, \
    p_folder_to_save, \
    p_folder_to_pick, \
    p_seed_index, \
    is_SC_hap_status, \
    how_long_after_p_endsim \
                    =     input_Var

    #p_attempts = int(p_population/p_islands) # ************************************************ IMPORTANT ***************************************************************


    # Get the current process ID
    pid = os.getpid()
    # Get the process information
    process = psutil.Process(pid)
    # Get the CPU core number
    cpu_core_id = process.cpu_num()

    np.savetxt(p_folder_to_save + '/pid.dat', [pid, cpu_core_id], fmt='%i')
    np.savetxt(p_folder_to_save + '/time.dat', [0], fmt='%i')

    #saving log file of parameters
    try:
        checking_x = open(p_folder_to_save + '/log_file.txt', 'rb')
        checking_x.close()
        checking_x = open(p_folder_to_save + '/seed_value.dat', 'rb')
        checking_x.close()
        p_seed_index = np.genfromtxt(p_folder_to_save + '/seed_value.dat').astype(int)

    except:
        np.savetxt(p_folder_to_save + '/seed_value.dat', [p_seed_index], fmt='%i')

        log_file = open(p_folder_to_save + '/log_file' + '.txt', "w")
        log_file.write("p_seed_index: " + str(p_seed_index) + "\n \n"
                        "generation time: " + str(datetime.now()) + "\n \n"
                        "directory: " + p_folder_to_save + "\n \n"
                        "population size: " + str(p_population) + "\n \n"
                        "# iteration: " + str(p_endsim) + "\n \n"
                        "allele length: " + str(p_length_rs) + "\n \n"
                        "initialized # of haplotypes: " + str(p_haps) + "\n \n"
                        "initialized # of SLFs in haplotype: " + str(p_slfs) + "\n \n"
                        "# AA bio-classes: " + str(4) + "\n \n"
                        "alpha: " + str(p_alpha) + "\n \n"
                        "delta: " + str(p_delta) + "\n \n"
                        "interaction threshold: " + str(p_ethreshold) + "\n \n"
                        "probability of mutation: " +"{:.2E}".format(Decimal(str(p_mutation))) + "\n \n"
                        "probability of duplication: " + "{:.2E}".format(Decimal(str(0))) + "\n \n"
                        "probability of deletion: " + "{:.2E}".format(Decimal(str(0))) + "\n \n"
                        "initialized as SC: " + str(is_SC_hap_status) + "\n \n"
                        "k (number of fertilization attempts per female): " + str(p_attempts) + "\n \n"
                        "RNase duplication: " + 'False' + "\n \n"
                        "RNase deletion: " + 'False' + "\n \n")
        log_file.close()

    np.random.seed(int(p_seed_index*1))
    #ra.seed(int(p_seed_index*1+1))

    # following show the number of random variables have been generated, \
    # hence next time this much random number will be discarted when start time is not zero
    numpy_random_integer = 0
    random_integer = 0



    weight = [0.5, 0.265, 0.113, 0.122]
    types_of_aa = [0,1,2,3]

    aa_rnases_dict = {} # sequence of AA in the corresponding RNase with some ID - together over all the time
    aa_slfs_dict = {} # sequence of AA in the corresponding SLF with some ID - together over all the time
    #aa_rnases_dict_count = {0:{}} # count of RNase(s) at a given time  ----- NOT NECESSARILY NEEDED
    #aa_slfs_dict_count = {0:{}} # count of SLF(s) at a given time      ----- NOT NECESSARILY NEEDED
    e_rf_dict = {} # interaction energy between RNase and SLF IDs - together over all the time
    haplotype_dict = {} # haplotype sequence as IDs of RNase and SLF(s) - together over all the time
    haplotype_count_dict = {} # count of haplotype(s) at a given time
    haplotype_count_inv_dict = {} # count of haplotype(s) at a given time

    # intial should be defined at initial time point: initial time or may not be ZERO
    # parental information
    mut_par_rnase_dict = {} # over time  -- mutant offspring: parent
    mut_par_slf_dict = {} # over time  -- mutant offspring: parent
    mut_par_hap_dict = {} # over time  -- mutant offspring: parent

    # reset in every fixed number of generation
    mut_temp_par_rnase_dict = {}
    mut_temp_par_slf_dict = {}
    mut_temp_par_hap_dict = {}

    range_over_population = list(range(int(p_population/2)))
    range_over_haplotypes = list(range(p_population))
    range_over_protein_per_hap = list(range(p_rnases))

    #
    #
    # initialization of the population                                                                                          BLOCK-I--------------------
    # -----------------------------------------------------------------------------------------------------------------------------------------------------
    if p_startsim == 0:
        samples_ini = np.random.randint(0,250-1)

        integerCal = int(p_population/p_rnases)
        temp_ancestors = list(range(p_rnases))

        if (os.path.exists(p_folder_to_save + '/initial_sample.dat')):

            samples_ini = np.genfromtxt(p_folder_to_save + '/initial_sample.dat').astype(int)
            temp_rnases = np.genfromtxt(p_folder_to_save + '/rnase_initial_{}.dat'.format(samples_ini)).astype(int)
            temp_slfs = np.genfromtxt(p_folder_to_save + '/slf_initial_{}.dat'.format(samples_ini)).astype(int)
            temp_no_of_slfs = np.genfromtxt(p_folder_to_save + '/slf_no_initial_{}.dat'.format(samples_ini)).astype(int) # number of slfs per haplotypeer
        
        else:

            temp_rnases = np.genfromtxt('{}/rnase_initial_{}.dat'.format(p_folder_to_pick, samples_ini)).astype(int)
            temp_slfs = np.genfromtxt('{}/slf_initial_{}.dat'.format(p_folder_to_pick, samples_ini)).reshape((p_rnases*(p_rnases-1), p_length_rs)).astype(int)
            temp_no_of_slfs = np.genfromtxt('{}/slf_no_initial_{}.dat'.format(p_folder_to_pick, samples_ini)).astype(int) # number of slfs per haplotypeer

            np.savetxt(p_folder_to_save + '/initial_sample.dat', [samples_ini], fmt='%i')
            np.savetxt(p_folder_to_save + '/rnase_initial_{}.dat'.format(samples_ini), temp_rnases, fmt='%i')
            np.savetxt(p_folder_to_save + '/slf_initial_{}.dat'.format(samples_ini), temp_slfs, fmt='%i')
            np.savetxt(p_folder_to_save + '/slf_no_initial_{}.dat'.format(samples_ini), temp_no_of_slfs, fmt='%i')


        e_rf_dict, haplotype_dict, \
        mut_temp_par_hap_dict, temp_ancestors, \
            aa_rnases_dict, aa_slfs_dict, \
            mut_temp_par_rnase_dict, mut_temp_par_slf_dict, \
                haplotype_count_inv_dict, haplotype_count_dict, \
                max_rnase_id, max_slf_id, \
                    max_hap_id, compatibility_status_main, \
                    complete_hap, haplotype_ancestors, \
                         haplotype_ids, haplotype_replacement = \
                                        Model.simulation_initials(p_population, p_rnases, p_ethreshold, p_startsim, p_haps, \
                                                                    p_slfs, integerCal, temp_rnases, temp_slfs, temp_no_of_slfs, \
                                                                        e_rf_dict, haplotype_dict, mut_temp_par_hap_dict, temp_ancestors, \
                                                                            aa_rnases_dict, aa_slfs_dict, mut_temp_par_rnase_dict, mut_temp_par_slf_dict, \
                                                                                haplotype_count_inv_dict, haplotype_count_dict)

        # status of each haplotype whether is_SC or not SC
        si_sc_counts = [-1 for _ in range_over_haplotypes] ########## ONLY WHEN START TIME IS ZERO
        for pop_ind in range_over_haplotypes:
            is_hap_sc, self_compatibility = Model.check_is_sc(in_haplotype = complete_hap[pop_ind], \
                                                                            in_e_rf_dict = e_rf_dict, \
                                                                                in_p_ethreshold = p_ethreshold)
            si_sc_counts[pop_ind] = is_hap_sc

        print("{:->100}".format(' initial pick and drop are done'), end='\n \n')

    else:
        # add last section here to start the code from where it was stopped
        print('right now, do nothing')
        'check everything above when start time is not ZERO'

        'define the following carefully when p_startsim != 0'
        # mut_temp_par_rnase_dict = {idx:idx for idx in current_rnase_ids}
        # mut_temp_par_slf_dict = {idx:idx for idx in current_slf_ids}
        # mut_temp_par_hap_dict = {idx:idx for idx in current_hap_ids}


    si_sc_counts_save = [[0, 0, 0] for _ in range(1 + (how_long_after_p_endsim+p_endsim)//25)] ########## ONLY WHEN START TIME IS ZERO
    si_sc_counts_gen_time = Model.find_counts(si_sc_counts, how_many=2)
    si_sc_counts_gen_time.append(p_startsim)
    si_sc_counts_save[p_startsim//25] = si_sc_counts_gen_time

    compatibility_status = np.sum(compatibility_status_main, axis=1)
    compatibility_status_save = [[0, 0, 0, 0] for _ in range(1 + (how_long_after_p_endsim+p_endsim)//25)] ########## ONLY WHEN START TIME IS ZERO
    compatibility_status_gen_time = Model.find_counts(compatibility_status, how_many=3)
    compatibility_status_gen_time.append(p_startsim)
    compatibility_status_save[p_startsim//25] = compatibility_status_gen_time

    genotype_details_at_hap_level = {}
    reshaped_si_sc_counts = np.array(si_sc_counts).reshape(p_population//2, 2)
    all_genotypes_at_hap_level_iter_gen = np.concatenate((compatibility_status.reshape(p_population//2, 1), reshaped_si_sc_counts), axis=1)
    genotype_unique, genotype_counts = np.unique(all_genotypes_at_hap_level_iter_gen, axis=0, return_counts=True)
    genotypes_at_hap_level_iter_gen_save = np.concatenate((genotype_unique, genotype_counts.reshape(len(genotype_counts), 1)), axis=1)
    genotype_details_at_hap_level[p_startsim] = genotypes_at_hap_level_iter_gen_save

    #
    #
    #
    # -------------------------------------------------------------------------------------------------------------
    single_ancestor_iter_cond, single_ancestor_iter_gen = False, 0





    # only once here, later on in the while loop
    max_rnase_id, max_slf_id, max_hap_id = max_rnase_id, max_slf_id, max_hap_id 
    # only once here, later on in the while loop, it will be keep on increasing in every generation 
    max_rnase_id_now, max_slf_id_now, max_hap_id_now = max_rnase_id, max_slf_id, max_hap_id  

    # this changes in every generation after selection  - see in the just after selection (finding a partner)
    temp_aa_rnases_dict, temp_aa_slfs_dict, temp_haplotype_dict = aa_rnases_dict, aa_slfs_dict, haplotype_dict
    temp_e_rf_dict = e_rf_dict

    complete_hap = complete_hap
    haplotype_ancestors = haplotype_ancestors
    haplotype_ids = haplotype_ids
    

    compatibility_status = compatibility_status 
    find_partner_attempts = [[0 for _ in range_over_population] for _ in range(1 + (how_long_after_p_endsim+p_endsim)//25)]
    find_partner_attempts[p_startsim//25] = [0 for _ in range_over_population]
    haplotype_replacement = haplotype_replacement

    # si_sc_counts = [0 for _ in range_over_haplotypes] ########## ONLY WHEN START TIME IS ZERO                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                           

    #
    #
    # -------------------------------------------------------------------------------

    iter_gen = p_startsim + 1
    d_iter = 500

    #while single_ancestor_iter_cond == False or iter_gen <= single_ancestor_iter_gen + p_endsim:

    tracker = 1
    iteration_to_save = 1

    condition_to_save_data = False
    while iter_gen <= p_endsim + how_long_after_p_endsim:

        current_all_rnases = complete_hap[:,0]
        current_all_slfs = complete_hap[:,1:]

        current_all_unique_rnases = list(np.unique(current_all_rnases, axis=None))
        current_all_unique_slfs = list(np.unique(current_all_slfs, axis=None))

        if iter_gen > p_endsim: # replace this time with ----               ---
            condition_to_save_data = True

        # temperaory variables that resets to zero at every generation
        temp_si_sc_counts = np.zeros(p_population, dtype='int64')
        temp_complete_hap = [0 for _ in range_over_haplotypes]



        #
        # ------------------------------------------------------------------ MUTATION             ---------------------------- BLOCK-II--------------------
        # -------------------------------------------------------------------------------------------------------------------------------------------------

        # total number of mutated proteins per generation with mutation probability p_mutation per AA
        no_of_mutations = sum(np.random.choice([0,1], p_population*p_rnases, p=[1-p_mutation*p_length_rs, p_mutation*p_length_rs]))
        # which indices are going to be mutated
        mutation_indices = np.random.choice(p_population*p_rnases, no_of_mutations, replace=True, p=None)
        # converting the indices in indices of haplotype indices and protein undices
        mut_hap_ind, mut_protein_ind = mutation_indices//p_rnases, mutation_indices%p_rnases
        # indicies of the AA to be mutated
        mut_protein_aa_ind = np.random.choice(p_length_rs, no_of_mutations, replace=True, p=None)
        # newely mutated AA values
        new_mutaed_aa_values = np.random.choice(types_of_aa, no_of_mutations, replace=True, p=weight)

        #print(mut_hap_ind)
        #print(mut_protein_ind)
        #print(mut_protein_aa_ind)
        #print(new_mutaed_aa_values)
        #print(np.unique(new_mutaed_aa_values, return_counts=True), '\n')



                                                # ███╗░░░███╗██╗░░░██╗████████╗░█████╗░████████╗██╗░█████╗░███╗░░██╗
                                                # ████╗░████║██║░░░██║╚══██╔══╝██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║
                                                # ██╔████╔██║██║░░░██║░░░██║░░░███████║░░░██║░░░██║██║░░██║██╔██╗██║
                                                # ██║╚██╔╝██║██║░░░██║░░░██║░░░██╔══██║░░░██║░░░██║██║░░██║██║╚████║
                                                # ██║░╚═╝░██║╚██████╔╝░░░██║░░░██║░░██║░░░██║░░░██║╚█████╔╝██║░╚███║
                                                # ╚═╝░░░░░╚═╝░╚═════╝░░░░╚═╝░░░╚═╝░░╚═╝░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══

        # █████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
        #
        # ------------------------------------------------------------------ MUTATION             ---------------------------- BLOCK-II--------------------
        # -------------------------------------------------------------------------------------------------------------------------------------------------

        for pop_ind, protein_ind, protein_aa_ind, mutated_aa in zip(mut_hap_ind, mut_protein_ind, mut_protein_aa_ind, new_mutaed_aa_values):
            tracker_hap_mut, tracker_slf_mut, tracker_rnase_mut, self_compatibility = 1, 0, 0, 0 # tracker under the population

            # here it is possible that two independent mutations can arrive at the same protein and also these two mutations can bring back to the original protein
            # but I am ignoring this here as it is going to be handeled in the data analysis

            max_hap_id_now += 1

            if protein_ind == 0:
                # 0 index corresponds to rnase
                tracker_rnase_mut = 1

                max_rnase_id_now += 1
                protein_id = complete_hap[pop_ind, protein_ind]

                if condition_to_save_data == True:
                    mut_temp_par_rnase_dict[max_rnase_id_now] = protein_id

                new_protein_seq = Model.mutated_sequence(in_seq = temp_aa_rnases_dict[protein_id], \
                                                            in_protein_aa_ind = protein_aa_ind, \
                                                                in_mutated_aa = mutated_aa)
                
                temp_aa_rnases_dict[max_rnase_id_now] = new_protein_seq
                complete_hap[pop_ind, protein_ind] = max_rnase_id_now

                current_all_unique_rnases.append(max_rnase_id_now)

                for non_mutated_slf_id in current_all_unique_slfs:
                    temp_e_rf_dict[(max_rnase_id_now, non_mutated_slf_id)] = Model.energyOfProtein(new_protein_seq, temp_aa_slfs_dict[non_mutated_slf_id])

            else:
                # other than 0 corrresponds to slf index
                tracker_slf_mut = 1
                max_slf_id_now += 1
                protein_id = complete_hap[pop_ind, protein_ind]
                
                if condition_to_save_data == True:
                    mut_temp_par_slf_dict[max_slf_id_now] = protein_id
                
                new_protein_seq = Model.mutated_sequence(in_seq = temp_aa_slfs_dict[protein_id], \
                                                            in_protein_aa_ind = protein_aa_ind, \
                                                                in_mutated_aa = mutated_aa)
                
                temp_aa_slfs_dict[max_slf_id_now] = new_protein_seq
                complete_hap[pop_ind, protein_ind] = max_slf_id_now

                current_all_unique_slfs.append(max_slf_id_now)

                for non_mutated_rnase_id in current_all_unique_rnases:
                    temp_e_rf_dict[(non_mutated_rnase_id, max_slf_id_now)] = Model.energyOfProtein(temp_aa_rnases_dict[non_mutated_rnase_id], new_protein_seq)

            temp_haplotype_dict[max_hap_id_now] = {}
            temp_haplotype_dict[max_hap_id_now]['rs_id'] = complete_hap[pop_ind]
            temp_haplotype_dict[max_hap_id_now]['birth'] = iter_gen
            temp_haplotype_dict[max_hap_id_now]['mutant'] = [tracker_rnase_mut, tracker_slf_mut]

            # checking is_hap SC-- 0: NO, 1: YES
            is_hap_sc, self_compatibility = Model.check_is_sc(in_haplotype = complete_hap[pop_ind], \
                                                                            in_e_rf_dict = temp_e_rf_dict, \
                                                                                in_p_ethreshold = p_ethreshold)
            si_sc_counts[pop_ind], self_compatibility = is_hap_sc, self_compatibility

            temp_haplotype_dict[max_hap_id_now]['is_sc'] = self_compatibility

            if condition_to_save_data == True:
                mut_temp_par_hap_dict[max_hap_id_now] = haplotype_ids[pop_ind]

            haplotype_ids[pop_ind] = max_hap_id_now

        max_rnase_id, max_slf_id, max_hap_id = max_rnase_id_now, max_slf_id_now, max_hap_id_now
        #print(max_rnase_id, max_slf_id, max_hap_id)


        compatibility_status_main = [-1 for _ in range_over_population] ########## ONLY WHEN START TIME IS ZERO
        for pop_ind in range_over_population:

            female_hap_1 = complete_hap[int(2*pop_ind)]
            female_hap_2 = complete_hap[int(2*pop_ind+1)]

            what_is_compatibility_status = Model.compatibility_status_of_diploid(in_haplotype_1 = female_hap_1, \
                                                                           in_haplotype_2 = female_hap_2, \
                                                                            in_e_rf_dict = temp_e_rf_dict, \
                                                                                in_p_ethreshold = p_ethreshold)
            
            compatibility_status_main[pop_ind] = what_is_compatibility_status

        compatibility_status_main = np.array(compatibility_status_main)
        compatibility_status = np.sum(compatibility_status_main, axis=1)


        #
        #
        #
        # 
        #
        # ------------------------------------------------------------------ SOME CALCULATIONS    ---------------------------- BLOCK-II--------------------
        # -------------------------------------------------------------------------------------------------------------------------------------------------
        

        temp_find_partner_attempts = [0 for _ in range_over_population]
        # temp_haplotype_replacement = [[_, _, _] for _ in range_over_population]
        
                                            # ░██████╗███████╗██╗░░░░░███████╗░█████╗░████████╗██╗░█████╗░███╗░░██╗
                                            # ██╔════╝██╔════╝██║░░░░░██╔════╝██╔══██╗╚══██╔══╝██║██╔══██╗████╗░██║
                                            # ╚█████╗░█████╗░░██║░░░░░█████╗░░██║░░╚═╝░░░██║░░░██║██║░░██║██╔██╗██║
                                            # ░╚═══██╗██╔══╝░░██║░░░░░██╔══╝░░██║░░██╗░░░██║░░░██║██║░░██║██║╚████║
                                            # ██████╔╝███████╗███████╗███████╗╚█████╔╝░░░██║░░░██║╚█████╔╝██║░╚███║
                                            # ╚═════╝░╚══════╝╚══════╝╚══════╝░╚════╝░░░░╚═╝░░░╚═╝░╚════╝░╚═╝░░╚══╝
        # -------------------------------------------------------------------------------------------------------------------------------------------------
        # █████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████


        temp_haplotype_ancestors = np.zeros(p_population, dtype='int64')
        temp_haplotype_ids = np.zeros(p_population, dtype='int64')

        # indices of si and sc haplotypes over each island to pick these later ------------ 1111
        # compatibility_status = np.array(compatibility_status)
        si_hap_indices = np.where(compatibility_status==0)[0]
        hsc_hap_indices = np.where(compatibility_status==1)[0]
        fsc_hap_indices = np.where(compatibility_status==2)[0]


        fraction_si, fraction_hsc, fraction_fsc = Model.find_counts(compatibility_status, how_many=3)
        sum_of_all_fractions = fraction_si + fraction_hsc + fraction_fsc
        fraction_si, fraction_hsc, fraction_fsc = \
            fraction_si/sum_of_all_fractions, fraction_hsc/sum_of_all_fractions, fraction_fsc/sum_of_all_fractions

        choosing_female_hap_prob = Model.diploid_female_probability([p_alpha, p_delta, fraction_si, fraction_hsc, fraction_fsc]) #alpha, delta, fs, fi
        haps_to_choose_as_female = np.random.choice([0, 1, 2, 3, 4], int(p_population/2), p=choosing_female_hap_prob)
        # {0: full SC self, 1: full SC out-cross, 2: half SC self, 3: half SC out-cross, 4: SI out-cross}


        for pop_Index, choosen_hap_as_female, in zip(range_over_population, haps_to_choose_as_female):

            temp_find_partner_attempts[pop_Index] = 0

            is_female_fertilized = False 
            while is_female_fertilized == False:

                # FSC as selfing
                if choosen_hap_as_female == 0:
                    female_new_pop_Index = np.random.choice(fsc_hap_indices)

                # FSC as out-crossed
                if choosen_hap_as_female == 1:
                    female_new_pop_Index = np.random.choice(fsc_hap_indices)

                # HSC as selfing
                if choosen_hap_as_female == 2:
                    female_new_pop_Index = np.random.choice(hsc_hap_indices)

                # HSC as out-crossed
                if choosen_hap_as_female == 3:
                    female_new_pop_Index = np.random.choice(hsc_hap_indices)

                # SI as out-crossed
                if choosen_hap_as_female == 4:
                    female_new_pop_Index = np.random.choice(si_hap_indices)


                if choosen_hap_as_female == 1 or choosen_hap_as_female == 3 or choosen_hap_as_female == 4:
                        
                    # partner from local + global population
                    range_over_attempts = range_over_haplotypes
                    pick_partner_range_ini = 0
                    pick_partner_range_end = p_population

                    for attempt_no in range_over_attempts:
                        temp_find_partner_attempts[pop_Index] += 1

                        random_hap = np.random.randint(pick_partner_range_ini, pick_partner_range_end) # (a, b), b is excluded
                        while random_hap == int(2*female_new_pop_Index) or random_hap == int(2*female_new_pop_Index+1):  
                            random_hap = np.random.randint(pick_partner_range_ini, pick_partner_range_end) # (a, b), b is excluded

                        current_male_hap = complete_hap[random_hap]
                        current_female_hap_1 = complete_hap[int(2*female_new_pop_Index)]
                        current_female_hap_2 = complete_hap[int(2*female_new_pop_Index+1)]
                        rnase_id_1, rnase_id_2, slfs_id = current_female_hap_1[0], current_female_hap_2[0], current_male_hap[1:]

                        # checking is_partner_found
                        female_haplotypes_being_fertilized = 0
                        for rnase_id in [rnase_id_1, rnase_id_2]:
                            for each_slf_id in slfs_id:
                                if temp_e_rf_dict[(rnase_id, each_slf_id)] < p_ethreshold:
                                    female_haplotypes_being_fertilized += 1
                                    break

                        if female_haplotypes_being_fertilized == 2:
                            is_female_fertilized = True
                        
                        if is_female_fertilized == True:

                            if np.random.random() < 0.5:
                                temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index)]
                                temp_complete_hap[int(2*pop_Index+1)] = complete_hap[random_hap]
                                temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index)]
                                temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[random_hap]
                                temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index)]
                                temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[random_hap]
                                temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index)]
                                temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[random_hap]
                                # haplotype_replacement[pop_Index] = [haplotype_ids[pop_Index], haplotype_ids[random_hap], haplotype_ids[random_hap]]
                            else:
                                temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index+1)]
                                temp_complete_hap[int(2*pop_Index+1)] = complete_hap[random_hap]
                                temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index+1)]
                                temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[random_hap]
                                temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index+1)]
                                temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[random_hap]
                                temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index+1)]
                                temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[random_hap]
                                # haplotype_replacement[pop_Index] = [haplotype_ids[female_new_pop_Index], haplotype_ids[random_hap], haplotype_ids[female_new_pop_Index]]
                            break


                    if is_female_fertilized == False:
                        choosen_hap_as_female = np.random.choice([0,1,2,3,4], 1, p=choosing_female_hap_prob)[0]

                        if choosen_hap_as_female == 0:
                            female_new_pop_Index = np.random.choice(fsc_hap_indices)
                        if choosen_hap_as_female == 2:
                            female_new_pop_Index = np.random.choice(hsc_hap_indices)

                if choosen_hap_as_female == 0:
                    is_female_fertilized = True # pollinated by self, 
                    temp_find_partner_attempts[pop_Index] = 0 # no attempts means selfing

                    random_prob = np.random.random()

                    if random_prob < 0.25: 
                        temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index)]
                        temp_complete_hap[int(2*pop_Index+1)] = complete_hap[int(2*female_new_pop_Index)]
                        temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index)]
                        temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[int(2*female_new_pop_Index)]
                        temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index)]
                        temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[int(2*female_new_pop_Index)]
                        temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index)]
                        temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[int(2*female_new_pop_Index)]

                    elif random_prob > 0.75:
                        temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index+1)]
                        temp_complete_hap[int(2*pop_Index+1)] = complete_hap[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[int(2*female_new_pop_Index+1)]
                        temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index+1)]
                        temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[int(2*female_new_pop_Index+1)]

                    else:
                        temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index)]
                        temp_complete_hap[int(2*pop_Index+1)] = complete_hap[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index)]
                        temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index)]
                        temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[int(2*female_new_pop_Index+1)]
                        temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index)]
                        temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[int(2*female_new_pop_Index+1)]

                if choosen_hap_as_female == 2:
                    is_female_fertilized = True # pollinated by self, 
                    temp_find_partner_attempts[pop_Index] = 0 # no attempts means selfing

                    if compatibility_status_main[female_new_pop_Index][0] == 1:
                        fertilizing_hap_index = 0
                    if compatibility_status_main[female_new_pop_Index][1] == 1:
                        fertilizing_hap_index = 1

                    if np.random.random() < 0.5:
                        temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index)]
                        temp_complete_hap[int(2*pop_Index+1)] = complete_hap[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index)]
                        temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[int(2*female_new_pop_Index+1)]
                        temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index)]
                        temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[int(2*female_new_pop_Index+1)]
                        temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index)]
                        temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[int(2*female_new_pop_Index+1)]
                        # haplotype_replacement[pop_Index] = [haplotype_ids[female_new_pop_Index], haplotype_ids[random_hap], haplotype_ids[female_new_pop_Index]]
                    else:
                        temp_complete_hap[int(2*pop_Index)] = complete_hap[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_complete_hap[int(2*pop_Index+1)] = complete_hap[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_haplotype_ancestors[int(2*pop_Index)] = haplotype_ancestors[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_haplotype_ancestors[int(2*pop_Index+1)] = haplotype_ancestors[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_haplotype_ids[int(2*pop_Index)] = haplotype_ids[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_haplotype_ids[int(2*pop_Index+1)] = haplotype_ids[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_si_sc_counts[int(2*pop_Index)] = si_sc_counts[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        temp_si_sc_counts[int(2*pop_Index+1)] = si_sc_counts[int(2*female_new_pop_Index+fertilizing_hap_index)]
                        # haplotype_replacement[pop_Index] = [haplotype_ids[female_new_pop_Index], haplotype_ids[random_hap], haplotype_ids[female_new_pop_Index]]


        complete_hap = np.array(temp_complete_hap)
        haplotype_ancestors = temp_haplotype_ancestors
        haplotype_ids = temp_haplotype_ids
        si_sc_counts = temp_si_sc_counts


        # selection ends here  -------------------------------------------------------

        #print(np.unique(haplotype_ids), len(np.unique(haplotype_ids)), '\n')
        #print (Model.find_counts(si_sc_counts, how_many=2), '\n')
            




        #
        #    SOME UPDATES AND SAVING THE DATA
        #
        #
        #
        #
        #
        #
        #
        #
        #
        # ------------------------------------------------------------------ SINGLE ANCESTOR UPDATE
        # when there is one ancestor d_iter becomes 10 and single_ancestor_iter_cond becomes True
        if len(np.unique(haplotype_ancestors)) == 1 and single_ancestor_iter_cond == False:
            single_ancestor_iter_cond = True
            single_ancestor_iter_gen = iter_gen
            np.savetxt(p_folder_to_save + '/xyz_single_ancestor.dat', np.array([single_ancestor_iter_gen]), fmt='%i')



        if iter_gen % 25 == 0:

            compatibility_status_main = [-1 for _ in range_over_population] ########## ONLY WHEN START TIME IS ZERO
            for pop_ind in range_over_population:

                female_hap_1 = complete_hap[int(2*pop_ind)]
                female_hap_2 = complete_hap[int(2*pop_ind+1)]

                what_is_compatibility_status = Model.compatibility_status_of_diploid(in_haplotype_1 = female_hap_1, \
                                                                            in_haplotype_2 = female_hap_2, \
                                                                                in_e_rf_dict = temp_e_rf_dict, \
                                                                                    in_p_ethreshold = p_ethreshold)
                
                compatibility_status_main[pop_ind] = what_is_compatibility_status

            compatibility_status_main = np.array(compatibility_status_main)
            compatibility_status = np.sum(compatibility_status_main, axis=1)
            compatibility_status_gen_time = Model.find_counts(compatibility_status, how_many=3)
            compatibility_status_gen_time.append(iter_gen)
            compatibility_status_save[iter_gen//25] = compatibility_status_gen_time

            reshaped_si_sc_counts = np.array(si_sc_counts).reshape(p_population//2, 2)
            all_genotypes_at_hap_level_iter_gen = np.concatenate((compatibility_status.reshape(p_population//2, 1), reshaped_si_sc_counts), axis=1)
            genotype_unique, genotype_counts = np.unique(all_genotypes_at_hap_level_iter_gen, axis=0, return_counts=True)
            genotypes_at_hap_level_iter_gen_save = np.concatenate((genotype_unique, genotype_counts.reshape(len(genotype_counts), 1)), axis=1)
            genotype_details_at_hap_level[iter_gen] = genotypes_at_hap_level_iter_gen_save

            find_partner_attempts[iter_gen//25] = temp_find_partner_attempts

        if iter_gen % 25 == 0 and condition_to_save_data == False:

            si_sc_counts_gen_time = Model.find_counts(si_sc_counts, how_many=2)
            si_sc_counts_gen_time.append(iter_gen)
            si_sc_counts_save[iter_gen//25] = si_sc_counts_gen_time

            # this section is to reduce the RAM by lowering the unused rnases, slfs, and haplotypes
            temp_temp_aa_rnases_dict = {}
            temp_temp_aa_slfs_dict   = {}
            temp_temp_haplotype_dict = {}
            temp_temp_e_rf_dict = {}

            current_rnase_ids = np.unique(complete_hap[:,0], axis=None)
            current_slf_ids = np.unique(complete_hap[:,1:], axis=None)
            current_hap_ids = np.unique(haplotype_ids, axis=None)

            for key in current_rnase_ids:
                temp_temp_aa_rnases_dict[key] = temp_aa_rnases_dict[key]

            for key in current_slf_ids:
                temp_temp_aa_slfs_dict[key] = temp_aa_slfs_dict[key]

            for key in current_hap_ids:
                temp_temp_haplotype_dict[key] = temp_haplotype_dict[key]

            for key_r in current_rnase_ids:
                for key_s in current_slf_ids:
                    temp_temp_e_rf_dict[(key_r, key_s)] = temp_e_rf_dict[(key_r, key_s)]

            temp_aa_rnases_dict = temp_temp_aa_rnases_dict
            temp_aa_slfs_dict = temp_temp_aa_slfs_dict
            temp_haplotype_dict = temp_temp_haplotype_dict
            temp_e_rf_dict = temp_temp_e_rf_dict


            if iter_gen == p_endsim and p_startsim == 0:
                mut_temp_par_rnase_dict = {idx:idx for idx in current_rnase_ids}
                mut_temp_par_slf_dict = {idx:idx for idx in current_slf_ids}
                mut_temp_par_hap_dict = {idx:idx for idx in current_hap_ids}


            # to lower the RAM uses
            current_rnase_ids = np.nan
            current_slf_ids = np.nan
            current_hap_ids = np.nan

            temp_temp_aa_rnases_dict = np.nan
            temp_temp_aa_slfs_dict   = np.nan
            temp_temp_haplotype_dict = np.nan
            temp_temp_e_rf_dict = np.nan

            # print(temp_temp_haplotype_dict[0])
            # print(temp_haplotype_dict[0], '\n')
            # print(temp_temp_aa_slfs_dict[0])
            # print(temp_aa_slfs_dict[0])
            # print(temp_temp_aa_rnases_dict[0])
            # print(temp_aa_rnases_dict[0], '--------------------------- \n')

            #print(iter_gen)

        #print(condition_to_save_data)
        gen_interval = 25 # the data will be saved in every 'this' generations once "condition_to_save_data" is True
        gen_difference_to_save_data = int(gen_interval*1) 
        if iter_gen % gen_interval == 0 and condition_to_save_data == True:

            # si_sc_counts_each_gen.append(si_sc_counts)
            si_sc_counts_gen_time = Model.find_counts(si_sc_counts, how_many=2)
            si_sc_counts_gen_time.append(iter_gen)
            si_sc_counts_save[iter_gen//25] = si_sc_counts_gen_time

            # this section is to reduce the RAM by lowering the unused rnases, slfs, and haplotypes
            temp_temp_aa_rnases_dict = {}
            temp_temp_aa_slfs_dict   = {}
            temp_temp_haplotype_dict = {}
            temp_temp_e_rf_dict = {}

            current_rnase_ids = np.unique(complete_hap[:,0], axis=None)
            current_slf_ids = np.unique(complete_hap[:,1:], axis=None)
            current_hap_ids = np.unique(haplotype_ids, axis=None)

            for key in current_rnase_ids:
                temp_temp_aa_rnases_dict[key] = temp_aa_rnases_dict[key]

            for key in current_slf_ids:
                temp_temp_aa_slfs_dict[key] = temp_aa_slfs_dict[key]

            for key, key_ind in zip(current_hap_ids, range(len(current_hap_ids))):
                temp_temp_haplotype_dict[key] = temp_haplotype_dict[key]

            for key_r in current_rnase_ids:
                for key_s in current_slf_ids:
                    temp_temp_e_rf_dict[(key_r, key_s)] = temp_e_rf_dict[(key_r, key_s)]


            temp_aa_rnases_dict = temp_temp_aa_rnases_dict
            temp_aa_slfs_dict = temp_temp_aa_slfs_dict
            temp_haplotype_dict = temp_temp_haplotype_dict
            temp_e_rf_dict = temp_temp_e_rf_dict
            

            if iter_gen % gen_difference_to_save_data == 0 and condition_to_save_data == True:

                current_hap_ids, current_hap_ids_inv, current_hap_ids_counts = np.unique(haplotype_ids, axis=0, return_counts=True, return_inverse=True)

                haplotype_count_dict[iter_gen] = np.array([current_hap_ids, current_hap_ids_counts])
                haplotype_count_inv_dict[iter_gen] = current_hap_ids_inv

                # to reduce the RAM
                times_of_gen_interval = 25 # it will save the data for 25 times for every true case


                if tracker == 1:
                    save_aa_rnases_dict = {}
                    save_aa_slfs_dict   = {}
                    save_haplotype_dict = {}
                    save_e_rf_dict = {}


                input_Var_1 = [p_folder_to_save, \
                                times_of_gen_interval, \
                                iteration_to_save, \
                                tracker, \
                                save_aa_rnases_dict, \
                                save_aa_slfs_dict, \
                                save_haplotype_dict, \
                                save_e_rf_dict, \
                                temp_aa_rnases_dict, \
                                temp_aa_slfs_dict, \
                                temp_haplotype_dict, \
                                temp_e_rf_dict]


                save_aa_rnases_dict, \
                    save_aa_slfs_dict, \
                        save_haplotype_dict, \
                            save_e_rf_dict, \
                                tracker, \
                                    iteration_to_save, \
                                                        = Model.dict_saving_with_low_ram(input_Var_1)


                current_hap_ids_inv = np.nan
                current_hap_ids_counts = np.nan

                #
                #     ALL OK
                #
                #
                #
                mut_par_rnase_dict =  Model.find_mut_parents(current_rnase_ids, mut_temp_par_rnase_dict, mut_par_rnase_dict)
                mut_par_slf_dict   =  Model.find_mut_parents(current_slf_ids, mut_temp_par_slf_dict, mut_par_slf_dict)
                mut_par_hap_dict =  Model.find_mut_parents(current_hap_ids, mut_temp_par_hap_dict, mut_par_hap_dict)

                mut_temp_par_rnase_dict = {idx:idx for idx in current_rnase_ids}
                mut_temp_par_slf_dict = {idx:idx for idx in current_slf_ids}
                mut_temp_par_hap_dict = {idx:idx for idx in current_hap_ids}



    
            # to lower the RAM uses
            current_rnase_ids = np.nan
            current_slf_ids = np.nan
            current_hap_ids = np.nan


            temp_temp_aa_rnases_dict = np.nan
            temp_temp_aa_slfs_dict   = np.nan
            temp_temp_haplotype_dict = np.nan
            temp_temp_e_rf_dict = np.nan

            # print(dict(np.array([current_hap_ids, temp_]).T))
            # print(list(current_rnase_ids), '\n')



        #
        # ---------------------------------------------------------- UPDATE and SAVE  ---------------------------------------- BLOCK-IV--------------------
        # -------------------------------------------------------------------------------------------------------------------------------------------------
        # to update the data in every d_iter generations to lower the load on the RAM and save the data in every new d_iter generations
        #if single_ancestor_iter_cond == False and iter_gen % d_iter == 0:

        gen_interval_save = 500
        if iter_gen % gen_interval_save == 0 and condition_to_save_data == True:

            input_Var_here = [p_folder_to_save,\
                                haplotype_count_dict, \
                                haplotype_count_inv_dict, \
                                mut_par_rnase_dict, \
                                mut_par_slf_dict, \
                                mut_par_hap_dict]
                                          
            Model.save_data(input_Var_here)


        if iter_gen % 500 == 0: 
            np.savetxt(p_folder_to_save + '/time.dat', np.array([iter_gen]), fmt='%i')
            # np.savetxt(p_folder_to_save + '/si_sc_counts.dat', np.array(compatibility_status), fmt='%i')
            np.savetxt(p_folder_to_save + '/si_sc_counts.dat', np.array(si_sc_counts_save), fmt='%i')
            np.savetxt(p_folder_to_save + '/compatibility_status.dat', np.array(compatibility_status_save), fmt='%i')
            np.savetxt(p_folder_to_save + '/find_partner_attempts.dat', np.array(find_partner_attempts), fmt='%i')
            Model.save_genotype_data([p_folder_to_save, genotype_details_at_hap_level])
            #print(iter_gen,  np.round(process.memory_info().rss/(1048576), decimals=0))


        #if iter_gen % 100 == 0:    
        #    print(iter_gen)

        iter_gen += 1


    #print(e_rf_dict)
    print('Ends|----|H:M:S|{}'.format(datetime.now() - start_time_1), '\n')


print('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
