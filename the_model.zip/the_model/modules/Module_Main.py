###############################################################################################################
##########################################################################################
import numpy as np
import pickle as pkl
import blosc # type: ignore
#import os
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################




class Main_model:

    global energy_tab

    energy_tab = np.array([[-1,  0,     0,     0],\
                            [0,  -0.75, -0.25, -0.25],\
                            [0,  -0.25,  1,    -1.25],\
                            [0,  -0.25, -1.25,  1]])




    #
    #
    # interaction energy between two proteins
    def energyOfProtein(rnase, slf):
        return sum([energy_tab[x,y] for x, y in zip(rnase, slf)])

    # energy_tab = { 0:{0:-1, 1:0,     2:0,     3:0    }, \
    #                1:{0:0,  1:-0.75, 2:-0.25, 3:-0.25}, \
    #                2:{0:0,  1:-0.25, 2:1,     3:-1.25}, \
    #                3:{0:0,  1:-0.25, 2:-1.25, 3:1    }  }
    
    # def energyOfProtein(rnase, slf):
    #     return sum([energy_tab[x][y] for x, y in zip(rnase, slf)]) # type: ignore


    #
    #
    # finding unique counts
    def find_counts(input_Var, how_many):

        f_counts = [0 for _ in range(how_many)]
        
        for key in input_Var:
            f_counts[key] += 1

        return f_counts


    #
    #
    # compatibility_status_of_diploid
    def compatibility_status_of_diploid(in_haplotype_1,in_haplotype_2, in_e_rf_dict, in_p_ethreshold):

        compatibility = [0, 0]

        # checking compatibility for haplotype 1
        self_all_slfs = in_haplotype_1[1:]
        check_fertilization_status_hap_1 = 0
        for self_rnase_id in [in_haplotype_1[0],in_haplotype_2[0]]:
            for each_self_slf_id in self_all_slfs:
                if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                    check_fertilization_status_hap_1 += 1
                    break

        if check_fertilization_status_hap_1 == 2:
            compatibility[0] = 1
    
        # checking compatibility for haplotype 2
        self_all_slfs = in_haplotype_2[1:]
        check_fertilization_status_hap_2 = 0
        for self_rnase_id in [in_haplotype_1[0],in_haplotype_2[0]]:
            for each_self_slf_id in self_all_slfs:
                if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                    check_fertilization_status_hap_2 += 1
                    break

        if check_fertilization_status_hap_2 == 2:
            compatibility[1] = 1
        
        
        return compatibility

    #
    #
    # initialization
    def simulation_initials(p_population, p_rnases, p_ethreshold, p_startsim, p_haps, p_slfs, \
                     integerCal, temp_rnases, temp_slfs, temp_no_of_slfs, \
                     e_rf_dict, haplotype_dict, mut_temp_par_hap_dict, temp_ancestors, aa_rnases_dict, \
                        aa_slfs_dict, mut_temp_par_rnase_dict, mut_temp_par_slf_dict, haplotype_count_inv_dict, haplotype_count_dict):
        

        # local function to check if a haplotype is SC or SI
        def local_check_is_sc(in_haplotype, in_e_rf_dict, in_p_ethreshold):

            is_sc = 0
            self_compatibility = 0
            self_rnase_id = in_haplotype[0]
            self_all_slfs = in_haplotype[1:]
            for each_self_slf_id in self_all_slfs:
                if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                    is_sc = 1
                    self_compatibility = 1
                    break

            return [is_sc, self_compatibility]


        # saving initial rnases and slfs with new ids starting with zero for both
        for rnase_ind in range(p_rnases):
            aa_rnases_dict[rnase_ind] = temp_rnases[rnase_ind]
            # mut_par_rnase_dict[rnase_ind] = rnase_ind   
            mut_temp_par_rnase_dict[rnase_ind] = rnase_ind
            
        for slf_ind in range(p_haps*p_slfs):
            aa_slfs_dict[slf_ind] = temp_slfs[slf_ind]
            # mut_par_slf_dict[slf_ind] = slf_ind     
            mut_temp_par_slf_dict[slf_ind] = slf_ind

        # making initial conditions
        haplotype_rnases = np.array(temp_ancestors*integerCal).astype(int)
        haplotype_slfs = np.array(list(np.arange(0,p_haps*p_slfs,1).reshape((p_haps,p_slfs)))*integerCal).astype(int)
        no_of_slfs_hap = np.array(list(temp_no_of_slfs)*integerCal).astype(int)
        haplotype_ancestors = np.array(temp_ancestors*integerCal).astype(int)
        haplotype_replacement = np.array([[_, _, _] for _ in range(p_rnases)]*integerCal).astype(int)
        haplotype_ids = np.array(temp_ancestors*integerCal).astype(int)

        # mutant parent of haplotype
        for hap_id in range(p_haps):
            # mut_par_hap_dict[hap_id] = hap_id   
             mut_temp_par_hap_dict[hap_id] = hap_id

        # in the tuple key, the first element is the id of rnase and second of slf
        for rnase_ind in range(p_rnases):
            for slf_ind in range(p_haps*p_slfs):
                e_rf_dict[(rnase_ind, slf_ind)] = sum([energy_tab[x,y] for x, y in zip(aa_rnases_dict[rnase_ind], aa_slfs_dict[slf_ind])])
                
        # adding initial details of each hap 
        for hap_id in range(p_haps):
            haplotype_dict[hap_id] = {}
            haplotype_dict[hap_id]['rs_id'] = np.concatenate(([hap_id], list(range(hap_id*p_slfs, (hap_id+1)*p_slfs))), axis=0)
            haplotype_dict[hap_id]['birth'] = 0 # birth iteration
            haplotype_dict[hap_id]['mutant'] = [0, 0] # 
            is_hap_sc, self_compatibility = local_check_is_sc(in_haplotype = haplotype_dict[hap_id]['rs_id'], \
                                                                            in_e_rf_dict = e_rf_dict, \
                                                                                in_p_ethreshold = p_ethreshold)
            haplotype_dict[hap_id]['is_sc'] = is_hap_sc # is selfcompatible


        index_to_suffle = np.arange(0,p_population,1)
        np.random.shuffle(index_to_suffle)

        haplotype_rnases = haplotype_rnases[index_to_suffle]
        haplotype_slfs = haplotype_slfs[index_to_suffle]
        haplotype_ancestors = haplotype_ancestors[index_to_suffle]
        haplotype_replacement = haplotype_replacement[index_to_suffle]
        no_of_slfs_hap = no_of_slfs_hap[index_to_suffle]
        haplotype_ids = haplotype_ids[index_to_suffle]

        complete_hap = np.concatenate((np.array([haplotype_rnases]).T, haplotype_slfs), axis=1)
        complete_hap = complete_hap[index_to_suffle]

        unique_haplotype_ids, unique_haplotype_ids_inv, unique_haplotype_ids_counts = np.unique(haplotype_ids, axis=0, return_counts=True, return_inverse=True)
        haplotype_count_inv_dict[p_startsim] = unique_haplotype_ids_inv

        # haplotype ids and counts
        haplotype_count_dict[p_startsim] = np.array([unique_haplotype_ids, unique_haplotype_ids_counts])  

        max_rnase_id, max_slf_id, max_hap_id = p_rnases-1, p_rnases*p_slfs -1, p_rnases




        #
        #
        # compatibility_status_of_diploid
        def local_compatibility_status_of_diploid(in_haplotype_1,in_haplotype_2, in_e_rf_dict, in_p_ethreshold):

            compatibility = [0, 0]

            # checking compatibility for haplotype 1
            self_all_slfs = in_haplotype_1[1:]
            check_fertilization_status_hap_1 = 0
            for self_rnase_id in [in_haplotype_1[0],in_haplotype_2[0]]:
                for each_self_slf_id in self_all_slfs:
                    if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                        check_fertilization_status_hap_1 += 1
                        break

            if check_fertilization_status_hap_1 == 2:
                compatibility[0] = 1
        
            # checking compatibility for haplotype 2
            self_all_slfs = in_haplotype_2[1:]
            check_fertilization_status_hap_2 = 0
            for self_rnase_id in [in_haplotype_1[0],in_haplotype_2[0]]:
                for each_self_slf_id in self_all_slfs:
                    if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                        check_fertilization_status_hap_2 += 1
                        break

            if check_fertilization_status_hap_2 == 2:
                compatibility[1] = 1
            
            
            return compatibility
    


        # status of each haplotype whether is_SC or not SC
        compatibility_status = [-1 for _ in range(int(p_population/2))] ########## ONLY WHEN START TIME IS ZERO
        for pop_ind in list(range(int(p_population/2))):

            female_hap_1 = complete_hap[int(2*pop_ind)]
            female_hap_2 = complete_hap[int(2*pop_ind+1)]

            what_is_compatibility_status = local_compatibility_status_of_diploid(in_haplotype_1 = female_hap_1, \
                                                                           in_haplotype_2 = female_hap_2, \
                                                                            in_e_rf_dict = e_rf_dict, \
                                                                                in_p_ethreshold = p_ethreshold)
            
            compatibility_status[pop_ind] = what_is_compatibility_status

        
        return [e_rf_dict, haplotype_dict, mut_temp_par_hap_dict, temp_ancestors, \
                aa_rnases_dict, aa_slfs_dict, mut_temp_par_rnase_dict, mut_temp_par_slf_dict, \
                    haplotype_count_inv_dict, haplotype_count_dict, max_rnase_id, max_slf_id, max_hap_id, \
                        np.array(compatibility_status), complete_hap, haplotype_ancestors, haplotype_ids, haplotype_replacement]
    

    
    #
    #
    # finding probabilities of different females; SC (self), SC (out-cross), SI (always out-crossed)
    def female_probability(input_Var):
        alpha, delta, fi, fs = input_Var
        fs, fi = fs/(fs+fi), fi/(fs+fi)

        fssp = fs * alpha * (1 - delta) / (1 - fs * alpha * delta)
        fsnp = fs * (1 - alpha) / (1 - fs * alpha * delta)
        fip  = fi / (1 - fs * alpha * delta)

        output = [fssp, fsnp, fip]
        output = np.array(output)/sum(output)

        return output



    #
    #
    # finding probabilities of different females; SC (self), SC (out-cross), SI (always out-crossed)
    def diploid_female_probability(input_Var):

        alpha, delta, fi, fhsc, ffsc = input_Var
        fi, fhsc, ffsc = fi/(fi+fhsc+ffsc), fhsc/(fi+fhsc+ffsc), ffsc/(fi+fhsc+ffsc)

        alpha_prime = (alpha/2)/(1 - (alpha/2)) # alpha/2
        tot_dying_fraction = ffsc*alpha*delta + fhsc*alpha_prime*delta
        surviving_fraction = 1 - tot_dying_fraction

        # full self-compatible self-fertilized
        ffsc_self = ffsc * alpha * (1 - delta) / surviving_fraction
        # full self-compatible out-crossed
        ffsc_out = ffsc * (1 - alpha) / surviving_fraction

        # half self-compatible self-fertilized
        fhsc_self = fhsc * alpha_prime * (1 - delta) / surviving_fraction
        # half self-compatible out-crossed
        fhsc_out = fhsc * (1 - alpha_prime) / surviving_fraction

        # self-incompatible out-crossed
        fi_out = fi / surviving_fraction

        output = [ffsc_self, ffsc_out, fhsc_self, fhsc_out, fi_out]
        output = np.array(output)/sum(output)

        return output



    # █████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████████
    #
    #                                                                    MUTATION            
    # -------------------------------------------------------------------------------------------------------------------------------------------------
    def mutation_module(input_Var):

        mut_hap_ind, mut_protein_ind, mut_protein_aa_ind, new_mutaed_aa_values, \
            complete_hap, condition_to_save_data, mut_par_rnase_dict, iter_gen, \
                p_length_rs, temp_aa_rnases_dict, mut_par_slf_dict, temp_aa_slfs_dict, \
                    temp_haplotype_dict,     \
                            = input_Var

        # pop_ind corresponding to new ids, \
        # it is to avoid assigning a new id to the same haplotype that earlier had mutation(s) either at rnase or at slf
        pop_ind_to_new_hap_id_dict = {}
        pop_ind_to_new_hap_id_list = []

        output = []

        return output


    #
    #
    # mutated sequence
    def mutated_sequence(in_seq, in_protein_aa_ind, in_mutated_aa):

        new_seq = in_seq + 0
        new_seq[in_protein_aa_ind] = in_mutated_aa

        return new_seq


    #
    #
    # checking a given hapllotype is self-compatible
    def check_is_sc(in_haplotype, in_e_rf_dict, in_p_ethreshold):

        is_sc = 0
        self_compatibility = 0
        self_rnase_id = in_haplotype[0]
        self_all_slfs = in_haplotype[1:]
        for each_self_slf_id in self_all_slfs:
            if in_e_rf_dict[(self_rnase_id, each_self_slf_id)] < in_p_ethreshold:
                is_sc = 1
                self_compatibility = 1
                break

        return [is_sc, self_compatibility]



    #
    #
    # for finding the mutant parent of rnases, slfs, and haplotypes
    def find_mut_parents(current_ids_dict, temp_offspring_parent_dict, to_update_offspring_parent_dict):

        for offspring_id in current_ids_dict:
            offspring_key = offspring_id
            
            while offspring_id != temp_offspring_parent_dict[offspring_id]:
                offspring_key = offspring_id
                offspring_id = temp_offspring_parent_dict[offspring_id]
            
            to_update_offspring_parent_dict[offspring_key] = temp_offspring_parent_dict[offspring_key]

        return to_update_offspring_parent_dict


    #
    #
    # handling the dictionaries to lower th RAM
    def dict_saving_with_low_ram(input_Var):

        p_folder_to_save, \
        times_of_gen_interval, \
        iteration_to_save, \
        tracker, \
        save_aa_rnases_dict, \
        save_aa_slfs_dict, \
        save_haplotype_dict, \
        save_e_rf_dict, \
        temp_aa_rnases_dict, \
        temp_aa_slfs_dict, \
        temp_haplotype_dict, \
        temp_e_rf_dict, \
                            = input_Var
        

        if tracker < times_of_gen_interval:
            save_aa_rnases_dict.update(temp_aa_rnases_dict)
            save_aa_slfs_dict.update(temp_aa_slfs_dict)
            save_haplotype_dict.update(temp_haplotype_dict)
            save_e_rf_dict.update(temp_e_rf_dict)
            tracker += 1

        else:
            save_aa_rnases_dict.update(temp_aa_rnases_dict)
            save_aa_slfs_dict.update(temp_aa_slfs_dict)
            save_haplotype_dict.update(temp_haplotype_dict)
            save_e_rf_dict.update(temp_e_rf_dict)

            pickled_data = pkl.dumps(save_aa_rnases_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
            compressed_pickle = blosc.compress(pickled_data)
            with open(p_folder_to_save + '/aa_rnases_dict_{}.pkl'.format(iteration_to_save), 'wb') as output:
                output.write(compressed_pickle)

            pickled_data = pkl.dumps(save_aa_slfs_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
            compressed_pickle = blosc.compress(pickled_data)
            with open(p_folder_to_save + '/aa_slfs_dict_{}.pkl'.format(iteration_to_save), 'wb') as output:
                output.write(compressed_pickle)

            pickled_data = pkl.dumps(save_e_rf_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
            compressed_pickle = blosc.compress(pickled_data)
            with open(p_folder_to_save + '/e_rf_dict_{}.pkl'.format(iteration_to_save), 'wb') as output:
                output.write(compressed_pickle)

            pickled_data = pkl.dumps(save_haplotype_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
            compressed_pickle = blosc.compress(pickled_data)
            with open(p_folder_to_save + '/hap_dict_{}.pkl'.format(iteration_to_save), 'wb') as output:
                output.write(compressed_pickle)

            tracker = 1
            iteration_to_save += 1


        return_data = [save_aa_rnases_dict,\
                        save_aa_slfs_dict,\
                        save_haplotype_dict,\
                        save_e_rf_dict,\
                        tracker, \
                        iteration_to_save]

        return return_data



    #
    #
    #  save data
    def save_data(input_Var):
            
        p_folder_to_save, \
        haplotype_count_dict, \
        haplotype_count_inv_dict, \
        mut_par_rnase_dict, \
        mut_par_slf_dict, \
        mut_par_hap_dict,\
                            = input_Var


        # with open(p_folder_to_save + '/aa_rnases_dict.pkl', 'wb') as output:
        #     pkl.dump(aa_rnases_dict, output, pkl.HIGHEST_PROTOCOL)

        # with open(p_folder_to_save + '/aa_slfs_dict.pkl', 'wb') as output:
        #     pkl.dump(aa_slfs_dict, output, pkl.HIGHEST_PROTOCOL)

        # with open(p_folder_to_save + '/e_rf_dict.pkl', 'wb') as output:
        #     pkl.dump(e_rf_dict, output, pkl.HIGHEST_PROTOCOL)

        # with open(p_folder_to_save + '/hap_dict.pkl', 'wb') as output:
        #     pkl.dump(haplotype_dict, output, pkl.HIGHEST_PROTOCOL)

        pickled_data = pkl.dumps(haplotype_count_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/hap_count_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(haplotype_count_inv_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/hap_count_inv_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(mut_par_rnase_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/mut_parents_rnase_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(mut_par_slf_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/mut_parents_slf_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(mut_par_hap_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/mut_parents_hap_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        # with open(p_folder_to_save + '/hap_ancestors_{}.pkl', 'wb') as output:
        #     pkl.dump(haplotype_ancestors, output, pkl.HIGHEST_PROTOCOL)
        # with open(p_folder_to_save + '/hap_replacement_{}.pkl', 'wb') as output:
        #     pkl.dump(haplotype_replacement, output, pkl.HIGHEST_PROTOCOL)
        # with open(p_folder_to_save + '/hap_sc_counts_{}.pkl', 'wb') as output:
        #     pkl.dump(si_sc_counts, output, pkl.HIGHEST_PROTOCOL)
        # with open(p_folder_to_save + '/hap_find_partner_attempts_{}.pkl', 'wb') as output:
        #     pkl.dump(find_partner_attempts, output, pkl.HIGHEST_PROTOCOL)



    #
    #
    #  save data
    def save_genotype_data(input_Var):
            
        p_folder_to_save, \
        genotype_details_at_hap_level \
                                    = input_Var
        
        pickled_data = pkl.dumps(genotype_details_at_hap_level, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_to_save + '/genotype_details_at_hap_level.pkl', 'wb') as output:
            output.write(compressed_pickle)

