#                             Haploid model parameters - Structured population
###############################################################################################################
##########################################################################################
# import modules.Module_Initial as Initialization # type: ignore
# import modules.Module_Main as Model # type: ignore
from modules.Module_Analysis import analysis as analysis
import input_folder_names as folder_names
from datetime import datetime
import numpy as np
import os
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
from decimal import Decimal
import pickle as pkl
import blosc
#import random as ra
#import pyarrow.parquet as pq
#import blosc
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print('Starts|--------|', start_time, '\n')



def class_structure(input_var):

    p_population, \
    p_mutation, \
    p_rnases, \
    p_attempts, \
    p_alpha, \
    p_delta, \
    p_ethreshold, \
    p_run_index, \
    p_folder_pick, \
    p_folder_save, \
                    =    input_var 


    if os.path.exists(p_folder_save + '/class_prior_haps.pkl') is False:

        #
        #       input DATA
        #
        # data_structure: {rnase_id: sequence , ...}
        # aa_rnases = pkl.load(open(p_folder_pick  + '/aa_rnases_dict.pkl', 'rb')) # key=(rnase_id, slf_id)
        aa_rnases = analysis.decompressing_blosc(p_folder_pick  + '/aa_rnases_dict.pkl')
        # data_structure: {slf_id: sequence , ...}
        # aa_slfs = pkl.load(open(p_folder_pick  + '/aa_slfs_dict.pkl', 'rb'))
        aa_slfs = analysis.decompressing_blosc(p_folder_pick  + '/aa_slfs_dict.pkl')
        # data_structure: {(rnase_id, slf_id): e_tot , ...}
        # e_rf = pkl.load(open(p_folder_pick  + '/e_rf_dict.pkl', 'rb'))
        e_rf = analysis.decompressing_blosc(p_folder_pick  + '/e_rf_dict.pkl')
        # data_structure: {time: {hap_id: counts , ...} , ...}
        # hap_ids_counts = pkl.load(open(p_folder_pick  + '/hap_count_dict.pkl', 'rb'))
        hap_ids_counts = analysis.decompressing_blosc(p_folder_pick  + '/hap_count_dict.pkl')
        # data_structure: {time: inverse , ...}
        # hap_ids_counts_inv = pkl.load(open(p_folder_pick  + '/hap_count_inv_dict.pkl', 'rb'))
        hap_ids_counts_inv = analysis.decompressing_blosc(p_folder_pick  + '/hap_count_inv_dict.pkl')
        # data_structure: {hap_id: {'rs_id': [rnase and slf ids], 'birth': birth time, 'is_sc': 0 or 1, 'mutant': [0 or 1, 0 or 1]} , ...}
        # hap_details = pkl.load(open(p_folder_pick  + '/hap_dict.pkl', 'rb'))
        hap_details = analysis.decompressing_blosc(p_folder_pick  + '/hap_dict.pkl')
        
        # generations over which analysis is done
        generations_temp = list(hap_ids_counts.keys())#[-1000:]
        generations_temp.sort()

        if generations_temp[0] == 0:    generations_temp.pop(0)

        the_gen_gap = int(25*1)
        generations = [each_time for each_time in generations_temp if each_time % the_gen_gap == 0]

        
        # structure; {time: {'class':{0: [classified hap ids ...], 1: [...], ...}, 
        # 			        'counts':{0: [classified hap ids counts ...], 1: [...], ...}, 
        # 			        'not_in_class': [unclassified SI hap ids, .... 
        # 							            total unclassified SI counts, 
        # 							                total SC counts]} , 
        # 							                                ... }
        class_structure = {gen_time: {'class':{}, 'counts':{}, 'not_in_class': []} for gen_time in generations}
        class_prior_haps ={gen_time: 0 for gen_time in generations}
        
        for gen_t, index in zip(generations, range(len(generations))):


            # -----------------------------
            #  
            #                                ░█████╗░██╗░░░░░░█████╗░░██████╗░██████╗  ██████╗░██████╗░██╗░█████╗░██████╗░
            #                                ██╔══██╗██║░░░░░██╔══██╗██╔════╝██╔════╝  ██╔══██╗██╔══██╗██║██╔══██╗██╔══██╗
            #                                ██║░░╚═╝██║░░░░░███████║╚█████╗░╚█████╗░  ██████╔╝██████╔╝██║██║░░██║██████╔╝
            #                                ██║░░██╗██║░░░░░██╔══██║░╚═══██╗░╚═══██╗  ██╔═══╝░██╔══██╗██║██║░░██║██╔══██╗
            #                                ╚█████╔╝███████╗██║░░██║██████╔╝██████╔╝  ██║░░░░░██║░░██║██║╚█████╔╝██║░░██║
            #                                ░╚════╝░╚══════╝╚═╝░░╚═╝╚═════╝░╚═════╝░  ╚═╝░░░░░╚═╝░░╚═╝╚═╝░╚════╝░╚═╝░░╚═╝
            #

            haps_id, haps_count = hap_ids_counts[gen_t]  # --------- data to save
            hap_as_rnase_slf_ids = [0 for _ in range(len(haps_count))]
            
            is_sc_status = [-1 for _ in range(len(haps_count))] # 0 means SI and 1 means SC # --------- data to save
            for each_hap_id, ind in zip(haps_id,range(len(haps_count))):
                hap_as_rnase_slf_ids[ind] = hap_details[each_hap_id]['rs_id']
                is_sc_status[ind] = hap_details[each_hap_id]['is_sc']

            ascending_index = np.argsort(haps_count)
            descending_index = ascending_index[::-1]

            haps_id = haps_id[descending_index]
            haps_count = haps_count[descending_index]
            is_sc_status = np.array(is_sc_status)[descending_index]
            hap_as_rnase_slf_ids = np.array(hap_as_rnase_slf_ids)[descending_index]

        
            hap_as_rnase_slf_ids = np.array(hap_as_rnase_slf_ids)

            compatibility_matrix = [-1 for _ in range(len(haps_count))] # --------- data to save
            

            for each_hap_top, hap_ind_top in zip(hap_as_rnase_slf_ids, range(len(hap_as_rnase_slf_ids))):
                temp_compatibility = [-1 for _ in range(len(haps_count))]
                
                rnase_id = each_hap_top[0]

                for each_hap_bot, hap_ind_bot in zip(hap_as_rnase_slf_ids, range(len(hap_as_rnase_slf_ids))):
                    slf_ids = each_hap_bot[1:]

                    is_compatible_as_male = 0
                    for each_slf_id in slf_ids:
                        e_tot = e_rf[(rnase_id, each_slf_id)]
                        if e_tot < p_ethreshold:
                            is_compatible_as_male = 1
                            break
                    
                    temp_compatibility[hap_ind_bot] = is_compatible_as_male
                compatibility_matrix[hap_ind_top] = temp_compatibility
            compatibility_matrix = np.array(compatibility_matrix)

            # print(compatibility_matrix, haps_id, haps_count, is_sc_status)
            # print(np.shape(compatibility_matrix), len(haps_id), len(haps_count), len(is_sc_status))
            # print(hap_as_rnase_slf_ids, '\n'*1)



            # -----------------------------
            #    
            #                                        ░█████╗░██╗░░░░░░█████╗░░██████╗░██████╗  ██████╗░░█████╗░░██████╗████████╗
            #                                        ██╔══██╗██║░░░░░██╔══██╗██╔════╝██╔════╝  ██╔══██╗██╔══██╗██╔════╝╚══██╔══╝
            #                                        ██║░░╚═╝██║░░░░░███████║╚█████╗░╚█████╗░  ██████╔╝██║░░██║╚█████╗░░░░██║░░░
            #                                        ██║░░██╗██║░░░░░██╔══██║░╚═══██╗░╚═══██╗  ██╔═══╝░██║░░██║░╚═══██╗░░░██║░░░
            #                                        ╚█████╔╝███████╗██║░░██║██████╔╝██████╔╝  ██║░░░░░╚█████╔╝██████╔╝░░░██║░░░
            #                                        ░╚════╝░╚══════╝╚═╝░░╚═╝╚═════╝░╚═════╝░  ╚═╝░░░░░░╚════╝░╚═════╝░░░░╚═╝░░░
            #




            comp_matrix = compatibility_matrix
            hap_ids = haps_id
            hap_counts = haps_count
            is_sc_status = is_sc_status

            class_prior_haps[gen_t] = [comp_matrix, hap_counts]

            # unclassified SC haplotypes:
            #####################################
            sc_hap_ids = [] # ----------------------------------------------- save data
            sc_hap_loc_ind = [] # index is locally defined not globally
            for temp_i in range(len(hap_counts)):
                if comp_matrix[temp_i, temp_i] == 1:
                    sc_hap_ids.append(hap_ids[temp_i])#;   print ('yes')
                    sc_hap_loc_ind.append(temp_i)


            # unclassified non sc haps ids
            non_sc_unclassified_haps_loc_index = []   # ----------------------------------------------- save data
            non_sc_haps_ids = np.setdiff1d(hap_ids, sc_hap_ids)  # as id only
            non_sc_haps_loc_index = np.setdiff1d(range(len(hap_ids)), sc_hap_loc_ind) # as local index only starting with 0, 1 ... len(has_ids)-1 


            if len(hap_ids[non_sc_haps_loc_index]) > 0: # else all are SC

                # classification
                #####################################
                classified_haps_ids, classified_haps_ids_count, initial_class_id = {},  {}, 0   # ----------------------------------------------- save data

                for each_hap_count, each_hap_ind, ind_temp in zip(hap_counts[non_sc_haps_loc_index], non_sc_haps_loc_index, range(len(non_sc_haps_loc_index))):

                    if ind_temp == 0:

                        classified_haps_ids[initial_class_id] = [each_hap_ind]
                        classified_haps_ids_count[initial_class_id] = [each_hap_count]

                    else:

                        compatible_over_class = 0
                        incompatible_over_class = 0
                        for each_class in list(classified_haps_ids.keys()):

                            compatible_over_class_haps, incompatible_over_class_haps = 0, 0

                            for each_hap_in_class in classified_haps_ids[each_class]:
                                if comp_matrix[each_hap_ind, each_hap_in_class] == 1 \
                                                        and comp_matrix[each_hap_in_class, each_hap_ind] == 1:
                                    compatible_over_class_haps += 1

                                elif comp_matrix[each_hap_ind, each_hap_in_class] == 0 \
                                                        and comp_matrix[each_hap_in_class, each_hap_ind] == 0:
                                    incompatible_over_class_haps += 1
                                else:
                                    'do nothing'

                            if compatible_over_class_haps == len(classified_haps_ids[each_class]):
                                compatible_over_class += 1

                            elif incompatible_over_class_haps == len(classified_haps_ids[each_class]):
                                incompatible_over_class += 1
                                class_index_incompatible_with = each_class

                            else:
                                'do nothing'

                        if compatible_over_class == len(list(classified_haps_ids.keys())):
                            initial_class_id += 1 # new class
                            classified_haps_ids[initial_class_id] = [each_hap_ind]
                            classified_haps_ids_count[initial_class_id] = [each_hap_count]

                        elif compatible_over_class == len(list(classified_haps_ids.keys())) - 1 and incompatible_over_class == 1: # part of one of the class
                            classified_haps_ids[class_index_incompatible_with].append(each_hap_ind)
                            classified_haps_ids_count[class_index_incompatible_with].append(each_hap_count)

                        else:
                            'this haplotype is unclassified'
                            non_sc_unclassified_haps_loc_index.append(each_hap_ind)

                # print(gen_t, classified_haps_ids, classified_haps_ids_count, hap_counts[non_sc_haps_loc_index])
                # print(list(hap_counts))
                # print(is_sc_status)
                # print(hap_ids, '\n')
                class_structure[gen_t]['class'] = {class_no: [hap_ids[hap_loc_ind] for hap_loc_ind in classified_haps_ids[class_no]] \
                                                            for class_no in list(classified_haps_ids.keys())}
                
                class_structure[gen_t]['counts'] = {class_no: [hap_count_temp for hap_count_temp in classified_haps_ids_count[class_no]] \
                                                            for class_no in list(classified_haps_ids_count.keys())}

                # for each_loc_ind in non_sc_unclassified_haps_loc_index:
                #     class_structure[gen_t]['not_in_class'].append(hap_ids[each_loc_ind])

                # appending the unclassified SI ids and total counts
                if len(non_sc_unclassified_haps_loc_index) > 0:
                    for each_loc_ind in non_sc_unclassified_haps_loc_index:
                        class_structure[gen_t]['not_in_class'].append(hap_ids[each_loc_ind])
                    non_sc_unclassified_haps_loc_index = np.array(non_sc_unclassified_haps_loc_index).astype(int)
                    all_unclassified_haps = sum(hap_counts[non_sc_unclassified_haps_loc_index])
                    class_structure[gen_t]['not_in_class'].append(all_unclassified_haps)
                else:
                    class_structure[gen_t]['not_in_class'].append(0)
                    class_structure[gen_t]['not_in_class'].append(0)
    
                # appending the unclassified SCs total counts just after unclassified total SI counts
                if len(sc_hap_loc_ind) > 0:
                    sc_hap_loc_ind = np.array(sc_hap_loc_ind)
                    class_structure[gen_t]['not_in_class'].append(sum(hap_counts[sc_hap_loc_ind]))
                else:
                    class_structure[gen_t]['not_in_class'].append(0)

                # print(class_structure[gen_t]['not_in_class'], sc_hap_loc_ind, '\n'*1)

            else:
                class_structure[gen_t]['class'] = {0: []}
                class_structure[gen_t]['counts'] = {0: []}      
                class_structure[gen_t]['not_in_class'].append(0)
                sc_hap_loc_ind = np.array(sc_hap_loc_ind)
                class_structure[gen_t]['not_in_class'].append(0)
                class_structure[gen_t]['not_in_class'].append(sum(hap_counts[sc_hap_loc_ind]))
                # print(gen_t, p_ethreshold, p_run_index, ' all are SC haps')

            
            # print(gen_t, p_ethreshold, p_run_index)

        #                                                   SAVE THE DATA
        # structure; {time: {'class':{0: [classified hap ids ...], 1: [...], ...}, 
        # 			        'counts':{0: [classified hap ids counts ...], 1: [...], ...}, 
        # 			        'not_in_class': [unclassified SI hap ids, .... 
        # 							            total unclassified SI counts, 
        # 							                total SC counts]} , 
        # 							                                ... }
        #with open(p_folder_save + '/class_structure_dict.pkl', 'wb') as output:
        #    pkl.dump(class_structure, output, pkl.HIGHEST_PROTOCOL)

        pickled_data = pkl.dumps(class_structure, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(p_folder_save + '/class_structure_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        print(p_run_index, p_ethreshold, '\n'*1)


        # # class_prior_haps = 0
        # class_prior_haps_Save = open(p_folder_save + '/class_prior_haps.pkl', "wb")
        # pkl.dump(class_prior_haps, class_prior_haps_Save)
        # class_prior_haps_Save.close()

    return 'done'


if __name__ == '__main__':


    all_input_paths = folder_names.the_path
    print(all_input_paths)
    input_path = all_input_paths[:] # must be a list of string of path(s)
    
    pop_list, mut_list, rr_list, \
        kk_list, al_list, dl_list, \
            eth_list, run_list, path_to_pick, \
                path_to_save = analysis.find_parms(input_path=input_path)

    N_Proces = 64
    Pool(N_Proces).map(class_structure, zip(pop_list[:], mut_list, rr_list, \
                                        kk_list, al_list, dl_list, \
                                            eth_list, run_list, path_to_pick, \
                                                                      path_to_save))




print('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
