#                             Haploid model parameters - Structured population
###############################################################################################################
##########################################################################################
# import modules.Module_Initial as Initialization # type: ignore
# import modules.Module_Main as Model # type: ignore
from modules.Module_Analysis import analysis as analysis
import input_folder_names as folder_names
from datetime import datetime
import numpy as np
import os
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
from decimal import Decimal
import pickle as pkl
import sys
import glob
import blosc
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print('Starts|--------|', start_time, '\n')



def merge_files(input_var):
    output_dir = input_var[-2]

    aa_rnases_dict = {}
    aa_slfs_dict   = {}
    e_rf_dict = {}
    hap_dict = {}

    if len(glob.glob(output_dir + '/aa_rnases_dict_*.pkl')) > 0:

        aa_rnases_dict_file = glob.glob(output_dir + '/aa_rnases_dict_*.pkl')
        aa_slfs_dict_file = glob.glob(output_dir + '/aa_slfs_dict_*.pkl')
        e_rf_dict_file = glob.glob(output_dir + '/e_rf_dict_*.pkl')
        hap_dict_file = glob.glob(output_dir + '/hap_dict_*.pkl')

        # this is usefull when script is rerun from some different time point other than ZERO
        if os.path.exists(output_dir + '/aa_rnases_dict.pkl'):
            aa_rnases_dict_file.append(output_dir + '/aa_rnases_dict.pkl')
            aa_slfs_dict_file.append(output_dir + '/aa_slfs_dict.pkl')
            e_rf_dict_file.append(output_dir + '/e_rf_dict.pkl')
            hap_dict_file.append(output_dir + '/hap_dict.pkl')

            # removing the data that are not useful now
            all_merging_files = [aa_rnases_dict_file[:-1], aa_slfs_dict_file[:-1], e_rf_dict_file[:-1], hap_dict_file[:-1]]

        else:
    
            # removing the data that are not useful now
            all_merging_files = [aa_rnases_dict_file, aa_slfs_dict_file, e_rf_dict_file, hap_dict_file]

        aa_rnases_dict = analysis.merge_dict(aa_rnases_dict, aa_rnases_dict_file)
        aa_slfs_dict = analysis.merge_dict(aa_slfs_dict, aa_slfs_dict_file)
        e_rf_dict = analysis.merge_dict(e_rf_dict, e_rf_dict_file)
        hap_dict = analysis.merge_dict(hap_dict, hap_dict_file)

        pickled_data = pkl.dumps(aa_rnases_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(output_dir + '/aa_rnases_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(aa_slfs_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(output_dir + '/aa_slfs_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(e_rf_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(output_dir + '/e_rf_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

        pickled_data = pkl.dumps(hap_dict, pkl.HIGHEST_PROTOCOL)  # returns data as a bytes object
        compressed_pickle = blosc.compress(pickled_data)
        with open(output_dir + '/hap_dict.pkl', 'wb') as output:
            output.write(compressed_pickle)

    

        print(all_merging_files)

        for each_file_name in all_merging_files:

            for each_file in each_file_name:

                if os.path.exists(each_file):
                    os.remove(each_file)
                else:
                    print("file does not exist") 


    print(output_dir, '\n'*1)

    return 'done'


if __name__ == '__main__':#

    all_input_paths = folder_names.the_path
    print(all_input_paths[:], '\n')
    input_path = all_input_paths[:] # must be a list of string of path(s)
    
    pop_list, mut_list, rr_list, \
        kk_list, al_list, dl_list, \
            eth_list, run_list, path_to_pick, \
                path_to_save = analysis.find_parms(input_path=input_path)


    N_Proces = 64
    Pool(N_Proces).map(merge_files, zip(pop_list, mut_list, rr_list, \
                                        kk_list, al_list, dl_list, \
                                            eth_list, run_list, path_to_pick, \
                                                            path_to_save))




print('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
