#                             Haploid model parameters - Structured population
###############################################################################################################
##########################################################################################
import modules.Module_Sim as Sim_v0 # type: ignore
import modules.Module_Initial as Initialization # type: ignore
from datetime import datetime
import numpy as np
import os
from multiprocessing import Pool    #, TimeoutError, Process, Queue, Pipe, Value, Array
from decimal import Decimal
import psutil
# import sys
# import pickle
# import random as ra
#import pdb
#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
#from pylab import genfromtxt
#import fit
#import networkx as nx
#import os, math, pdb, time, random as ra, matplotlib.pyplot as plt, sys
#import collections
#import seaborn as sns; sns.set()
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print('Starts|--------|', start_time)


#
#             A general haploid model run 
#
###########################################################################################
#
#
###############################################################################################################

if __name__ == '__main__':
    
    N_Proces = 8

    population_main, mutation_main, rnases_main, attempts_main, alpha_main, delta_main, \
    ethreshold_main, length_rs_main, threshsc_main, startsim_main, \
    endsim_main, haps_main, slfs_main, samples_main, folder_main_save \
                                        =            Initialization.initialize.parameters(True)

    folder_main_pick = ['./initial_pop' + '/ethe{}'.format(eth_t)  for eth_t in ethreshold_main]
    print(ethreshold_main)
    print(samples_main)

    no_unique_runs = len(np.unique(samples_main))
    total_runs = len(samples_main)

    seed_index_main = [0 for _ in range(int(total_runs/no_unique_runs))]
    for ix in range(int(total_runs/no_unique_runs)):
        seed_index_temp = []
        how_many_initials = 250
        for __ in range(how_many_initials):
            random_seed = np.random.randint(0,how_many_initials-1) # (a, b), b is excluded
            if random_seed not in seed_index_temp:
                seed_index_temp.append(random_seed)
            if len(seed_index_temp) == no_unique_runs:   
                break
        seed_index_main[ix] = seed_index_temp

    seed_index_main = np.array(seed_index_main).flatten()
    seed_index_main = list(seed_index_main)

    seed_index_main = seed_index_main #list(range(len(samples_main)))
    is_SC_hap_status_main = [False for _alpha in alpha_main]

    '''startsim_main # change it from ZERO to non-ZERO to start the simulation from where it was stopped'''
    # how long to run after 'end' simulation time
    after_end_sim = [int(10_000) for _ in alpha_main] # this should be the multiple of 2500

    input_Parameters = zip(population_main, mutation_main, rnases_main, attempts_main, alpha_main, delta_main, \
                        ethreshold_main, length_rs_main, threshsc_main, startsim_main, \
                        endsim_main, haps_main, slfs_main, samples_main, folder_main_save, folder_main_pick, seed_index_main, \
                        is_SC_hap_status_main, after_end_sim)

    Pool(N_Proces).map(Sim_v0.SI_Structured_Pop_Evo_Main, input_Parameters)


print('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
